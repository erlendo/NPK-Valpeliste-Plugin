<?php
/**
 * Test individual badge API directly 
 */

echo "=== INDIVIDUAL BADGE API TEST ===\n\n";

$login_url = 'https://pointer.datahound.no/admin';
$login_action_url = 'https://pointer.datahound.no/admin/index/auth';

// Initialize cURL with proper session
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $login_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => '/tmp/test_cookies.txt',
    CURLOPT_COOKIEFILE => '/tmp/test_cookies.txt',
    CURLOPT_USERAGENT => 'NPK Test',
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false
]);

$login_page = curl_exec($ch);

// Login
$login_data = http_build_query([
    'admin_username' => 'demo',
    'admin_password' => 'demo', 
    'login' => 'login'
]);

curl_setopt_array($ch, [
    CURLOPT_URL => $login_action_url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $login_data,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/x-www-form-urlencoded',
        'Referer: ' . $login_url
    ]
]);

$login_response = curl_exec($ch);
$login_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
echo "Login HTTP code: $login_code\n";

// Test known dogs with badges
$test_dogs = [
    'NO34007/19', // Langlandsmoens Kevlar (har elite fra tidligere test)
    'NO36477/22', // Test hund 
    'NO32123/18', // Annen test
];

foreach ($test_dogs as $regnr) {
    echo "\n--- Testing $regnr ---\n";
    
    $dog_url = "https://pointer.datahound.no/admin/product/getdog?id=" . urlencode($regnr);
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $dog_url,
        CURLOPT_POST => false,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json'
        ]
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    echo "HTTP code: $http_code\n";
    
    if ($http_code == 200) {
        $dog_data = json_decode($response, true);
        if ($dog_data) {
            echo "eliteh: " . (isset($dog_data['eliteh']) ? $dog_data['eliteh'] : 'not set') . "\n";
            echo "avlsh: " . (isset($dog_data['avlsh']) ? $dog_data['avlsh'] : 'not set') . "\n";
            echo "premie: " . (isset($dog_data['premie']) ? $dog_data['premie'] : 'not set') . "\n";
            
            // Look for other badge fields
            $badge_fields = ['elite', 'avl', 'vplcolor', 'vpltooltip', 'health'];
            foreach ($badge_fields as $field) {
                if (isset($dog_data[$field])) {
                    echo "$field: " . $dog_data[$field] . "\n";
                }
            }
        } else {
            echo "Invalid JSON response\n";
            echo "Response: " . substr($response, 0, 200) . "\n";
        }
    } else {
        echo "Failed with HTTP $http_code\n";
        echo "Response: " . substr($response, 0, 200) . "\n";
    }
}

curl_close($ch);

echo "\n=== Test complete ===\n";
?>
