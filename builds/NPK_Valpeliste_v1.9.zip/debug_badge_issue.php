<?php
/**
 * Debug why badges are not showing
 */

require_once 'npk_valpeliste.php';

echo "<h2>Debug: Hvorfor vises ingen badges?</h2>\n";

// Test med ekte API data
if (function_exists('authenticate_datahound') && function_exists('fetch_valpeliste_data')) {
    
    echo "<h3>1. Test API tilkobling</h3>\n";
    
    // Autentiser
    $auth_result = authenticate_datahound();
    if ($auth_result) {
        echo "✅ Autentisering vellykket\n";
        
        // Hent data
        $api_data = fetch_valpeliste_data();
        if ($api_data && isset($api_data['dogs']) && !empty($api_data['dogs'])) {
            echo "✅ API data hentet: " . count($api_data['dogs']) . " kull\n";
            
            // Velg første hund for testing
            $first_dog = $api_data['dogs'][0];
            
            echo "<h3>2. Rå API data for første hund</h3>\n";
            echo "<pre>";
            print_r($first_dog);
            echo "</pre>";
            
            echo "<h3>3. Test data-processing</h3>\n";
            
            if (function_exists('process_valp_data')) {
                $processed = process_valp_data([$first_dog]);
                
                echo "Prosessert data:\n";
                echo "<pre>";
                print_r($processed[0]);
                echo "</pre>";
                
                echo "<h3>4. Test get_dog_status for far</h3>\n";
                if (function_exists('get_dog_status')) {
                    $father_status = get_dog_status($processed[0], 'father', true);
                    echo "Far status:\n";
                    echo "<pre>";
                    print_r($father_status);
                    echo "</pre>";
                    
                    echo "<h3>5. Test get_dog_status for mor</h3>\n";
                    $mother_status = get_dog_status($processed[0], 'mother', true);
                    echo "Mor status:\n";
                    echo "<pre>";
                    print_r($mother_status);
                    echo "</pre>";
                    
                    // Sjekk hva som er galt
                    echo "<h3>6. Diagnose</h3>\n";
                    
                    if (!$father_status['avlshund'] && !$father_status['elitehund'] && 
                        !$mother_status['avlshund'] && !$mother_status['elitehund']) {
                        echo "❌ PROBLEM: Ingen badges tildelt!\n";
                        
                        // Sjekk originaldata
                        echo "\n<strong>Original API flags:</strong>\n";
                        echo "avlsh: " . (isset($first_dog['avlsh']) ? $first_dog['avlsh'] : 'ikke satt') . "\n";
                        echo "eliteh: " . (isset($first_dog['eliteh']) ? $first_dog['eliteh'] : 'ikke satt') . "\n";
                        echo "premie: " . (isset($first_dog['premie']) ? $first_dog['premie'] : 'ikke satt') . "\n";
                        echo "PremieM: " . (isset($first_dog['PremieM']) ? $first_dog['PremieM'] : 'ikke satt') . "\n";
                        
                    } else {
                        echo "✅ Badges fungerer!\n";
                    }
                } else {
                    echo "❌ get_dog_status funksjonen ikke funnet\n";
                }
            } else {
                echo "❌ process_valp_data funksjonen ikke funnet\n";
            }
            
        } else {
            echo "❌ Kunne ikke hente API data\n";
            var_dump($api_data);
        }
    } else {
        echo "❌ Autentisering feilet\n";
    }
} else {
    echo "❌ Nødvendige funksjoner ikke funnet\n";
}
?>
