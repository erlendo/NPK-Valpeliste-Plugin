<?php
/**
 * WordPress Integration Test for NPK Valpeliste Plugin
 * Tester om pluginet er riktig registrert og shortcode fungerer
 */

// Mock WordPress functions som trengs for testing
if (!function_exists('add_shortcode')) {
    function add_shortcode($tag, $callback) {
        global $wpk_shortcodes;
        $wpk_shortcodes[$tag] = $callback;
        echo "✅ Shortcode '$tag' registrert med callback: $callback\n";
    }
}

if (!function_exists('add_action')) {
    function add_action($hook, $callback) {
        $callback_name = is_string($callback) ? $callback : (is_callable($callback) ? 'Anonymous function' : 'Unknown');
        echo "✅ Action '$hook' registrert med callback: $callback_name\n";
    }
}

if (!function_exists('wp_send_json_error')) {
    function wp_send_json_error($message) {
        echo "JSON ERROR: $message\n";
    }
}

if (!function_exists('wp_send_json_success')) {
    function wp_send_json_success($data) {
        echo "JSON SUCCESS: " . print_r($data, true) . "\n";
    }
}

if (!function_exists('plugin_dir_path')) {
    function plugin_dir_path($file) {
        return dirname($file) . '/';
    }
}

if (!function_exists('plugin_dir_url')) {
    function plugin_dir_url($file) {
        return 'http://example.com/wp-content/plugins/' . basename(dirname($file)) . '/';
    }
}

if (!defined('ABSPATH')) {
    define('ABSPATH', '/fake/wordpress/path/');
}

// Additional WordPress function mocks
if (!function_exists('register_activation_hook')) {
    function register_activation_hook($file, $callback) {
        $callback_name = is_string($callback) ? $callback : 'Anonymous function';
        echo "✅ Activation hook registrert for plugin med callback: $callback_name\n";
    }
}

if (!function_exists('register_deactivation_hook')) {
    function register_deactivation_hook($file, $callback) {
        $callback_name = is_string($callback) ? $callback : 'Anonymous function';
        echo "✅ Deactivation hook registrert for plugin med callback: $callback_name\n";
    }
}

if (!function_exists('error_log')) {
    function error_log($message) {
        echo "LOG: $message\n";
    }
}

echo "🔍 TESTING NPK VALPELISTE WORDPRESS INTEGRATION\n";
echo "=" . str_repeat("=", 50) . "\n\n";

// Test 1: Include plugin fil
echo "1. Testing plugin inclusion...\n";
try {
    require_once 'npk_valpeliste.php';
    echo "✅ Plugin hovedfil inkludert uten feil\n\n";
} catch (Exception $e) {
    echo "❌ Feil ved inkludering av plugin: " . $e->getMessage() . "\n\n";
    exit(1);
}

// Test 2: Sjekk om shortcode er registrert
echo "2. Testing shortcode registration...\n";
global $wpk_shortcodes;
if (isset($wpk_shortcodes['npk_valpeliste'])) {
    echo "✅ Shortcode [npk_valpeliste] er registrert\n";
    $callback = $wpk_shortcodes['npk_valpeliste'];
    echo "   Callback function: $callback\n\n";
} else {
    echo "❌ Shortcode [npk_valpeliste] ikke funnet\n\n";
}

// Test 3: Test shortcode funksjonalitet
echo "3. Testing shortcode functionality...\n";
if (function_exists('npk_valpeliste_shortcode')) {
    echo "✅ npk_valpeliste_shortcode() function exists\n";
    
    // Test shortcode execution med timeout
    $start_time = microtime(true);
    $timeout = 15; // 15 sekunder timeout
    
    echo "   Executing shortcode (max $timeout seconds)...\n";
    
    // Set time limit
    set_time_limit($timeout + 5);
    
    try {
        $result = npk_valpeliste_shortcode([]);
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 2);
        
        if ($result) {
            $result_length = strlen($result);
            echo "✅ Shortcode executed successfully in {$execution_time}s\n";
            echo "   Output length: $result_length characters\n";
            
            // Sjekk for feilmeldinger
            if (strpos($result, 'npk-error') !== false) {
                echo "⚠️  Shortcode contains error div\n";
                echo "   Error content preview: " . substr($result, 0, 200) . "...\n";
            } else if (strpos($result, 'npk-valpeliste') !== false) {
                echo "✅ Shortcode generated valid HTML structure\n";
                
                // Tell antall badges
                $badge_count = substr_count($result, 'class="badge');
                echo "   Badges found in output: $badge_count\n";
                
                // Tell antall kull
                $kull_count = substr_count($result, 'npk-kull-card');
                echo "   Kull cards found: $kull_count\n";
            }
        } else {
            echo "❌ Shortcode returned empty result\n";
        }
        
    } catch (Exception $e) {
        echo "❌ Shortcode execution failed: " . $e->getMessage() . "\n";
    }
} else {
    echo "❌ npk_valpeliste_shortcode() function not found\n";
}

echo "\n4. Testing core data function...\n";
if (function_exists('npk_get_live_data')) {
    echo "✅ npk_get_live_data() function exists\n";
    
    // Quick data test
    $start_time = microtime(true);
    try {
        $data = npk_get_live_data();
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 2);
        
        if (isset($data['error'])) {
            echo "❌ Data function returned error: " . $data['error'] . "\n";
        } else if (isset($data['kull'])) {
            echo "✅ Data function working in {$execution_time}s\n";
            echo "   Kull count: " . count($data['kull']) . "\n";
            if (isset($data['metadata']['badge_stats'])) {
                echo "   Badge stats: " . print_r($data['metadata']['badge_stats'], true);
            }
        } else {
            echo "❌ Data function returned invalid structure\n";
        }
    } catch (Exception $e) {
        echo "❌ Data function failed: " . $e->getMessage() . "\n";
    }
} else {
    echo "❌ npk_get_live_data() function not found\n";
}

echo "\n" . str_repeat("=", 60) . "\n";
echo "WORDPRESS INTEGRATION TEST COMPLETE\n";
echo str_repeat("=", 60) . "\n";
?>
