<?php
echo "=== Test av Nåværende Versjon API-kall ===\n\n";

// Simulate WordPress functions for standalone testing
function wp_remote_get($url, $args) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $args['timeout'] ?? 30);
    curl_setopt($ch, CURLOPT_USERAGENT, $args['user-agent'] ?? 'NPK Valpeliste Plugin');
    curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/test_cookies.txt');
    curl_setopt($ch, CURLOPT_COOKIEFILE, '/tmp/test_cookies.txt');
    
    if (isset($args['headers'])) {
        $headers = [];
        foreach ($args['headers'] as $key => $value) {
            $headers[] = "$key: $value";
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'response' => ['code' => $http_code],
        'body' => $response,
        'headers' => []
    ];
}

function wp_remote_post($url, $args) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $args['timeout'] ?? 30);
    curl_setopt($ch, CURLOPT_USERAGENT, $args['user-agent'] ?? 'NPK Valpeliste Plugin');
    curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/test_cookies.txt');
    curl_setopt($ch, CURLOPT_COOKIEFILE, '/tmp/test_cookies.txt');
    
    if (isset($args['body'])) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($args['body']));
    }
    
    if (isset($args['headers'])) {
        $headers = [];
        foreach ($args['headers'] as $key => $value) {
            $headers[] = "$key: $value";
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'response' => ['code' => $http_code],
        'body' => $response,
        'headers' => []
    ];
}

function wp_remote_retrieve_response_code($response) {
    return $response['response']['code'];
}

function wp_remote_retrieve_body($response) {
    return $response['body'];
}

function wp_remote_retrieve_cookies($response) {
    return [];
}

function wp_remote_retrieve_headers($response) {
    return $response['headers'];
}

function is_wp_error($response) {
    return false;
}

// Test the current authentication process
echo "🔐 AUTENTISERING:\n";
$login_url = 'https://pointer.datahound.no/admin';
$login_action_url = 'https://pointer.datahound.no/admin/index/auth';

echo "1. Henter login-side...\n";
$response = wp_remote_get($login_url, [
    'timeout' => 30,
    'user-agent' => 'NPK Valpeliste Plugin Test',
    'headers' => [
        'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    ]
]);

$login_body = wp_remote_retrieve_body($response);
echo "   Status: HTTP " . wp_remote_retrieve_response_code($response) . "\n";
echo "   Size: " . strlen($login_body) . " bytes\n";

// Extract CSRF token
$csrf_token = '';
if (preg_match('/<input[^>]*name=["\']_token["\'][^>]*value=["\']([^"\']*)["\']/', $login_body, $matches)) {
    $csrf_token = $matches[1];
    echo "   CSRF token: " . substr($csrf_token, 0, 20) . "...\n";
}

echo "\n2. Logger inn...\n";
$login_data = [
    'admin_username' => 'demo',
    'admin_password' => 'demo',
    'login' => 'login'
];
if ($csrf_token) {
    $login_data['_token'] = $csrf_token;
}

$login_response = wp_remote_post($login_action_url, [
    'timeout' => 30,
    'user-agent' => 'NPK Valpeliste Plugin Test',
    'headers' => [
        'Content-Type' => 'application/x-www-form-urlencoded',
        'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Referer' => $login_url,
        'Origin' => 'https://pointer.datahound.no'
    ],
    'body' => $login_data
]);

$response_code = wp_remote_retrieve_response_code($login_response);
echo "   Status: HTTP $response_code\n";

echo "\n📡 API-KALL:\n";
$api_url = 'https://pointer.datahound.no/admin/product/getvalpeliste';
echo "Endpoint: $api_url\n";

$api_response = wp_remote_get($api_url, [
    'timeout' => 30,
    'user-agent' => 'NPK Valpeliste Plugin Test',
    'headers' => [
        'Accept' => 'application/json, text/html, */*',
        'Cache-Control' => 'no-cache, no-store, must-revalidate',
        'Pragma' => 'no-cache',
        'Expires' => '0',
        'Referer' => 'https://pointer.datahound.no/',
        'X-Requested-With' => 'XMLHttpRequest',
        'Origin' => 'https://pointer.datahound.no'
    ]
]);

$api_code = wp_remote_retrieve_response_code($api_response);
$api_body = wp_remote_retrieve_body($api_response);

echo "Status: HTTP $api_code\n";
echo "Response size: " . strlen($api_body) . " bytes\n";

if ($api_code === 200) {
    $json_data = json_decode($api_body, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($json_data)) {
        echo "✅ Valid JSON data!\n";
        
        if (isset($json_data['dogs'])) {
            echo "Records found: " . count($json_data['dogs']) . "\n";
            if (isset($json_data['totalCount'])) {
                echo "Total count (API): " . $json_data['totalCount'] . "\n";
            }
            
            echo "\n📊 BADGE ANALYSE:\n";
            foreach ($json_data['dogs'] as $index => $litter) {
                echo "KUID " . $litter['KUID'] . ": ";
                $avlsh = $litter['avlsh'] ?? 'null';
                $eliteh = $litter['eliteh'] ?? 'null';
                echo "avlsh=$avlsh, eliteh=$eliteh";
                if ($avlsh === '1' || $eliteh === '1') {
                    echo " ⭐";
                }
                echo "\n";
            }
        } else {
            echo "Data structure: " . implode(', ', array_keys($json_data)) . "\n";
        }
    } else {
        echo "❌ JSON error: " . json_last_error_msg() . "\n";
        echo "Content preview: " . substr($api_body, 0, 300) . "...\n";
    }
} else {
    echo "❌ HTTP Error\n";
    echo "Content preview: " . substr($api_body, 0, 300) . "...\n";
}

echo "\n=== SAMMENDRAG ===\n";
echo "Plugin bruker WordPress wp_remote_* funksjoner\n";
echo "Autentisering: Session cookies via admin login\n";
echo "Endpoint: https://pointer.datahound.no/admin/product/getvalpeliste\n";
echo "Badge data: Kun på kull-nivå (avlsh, eliteh)\n";
?>
