<?php
/**
 * Test og demonstrasjon av NPK Data Extractor
 * Viser hvordan klassen brukes og valideringer av resultater
 */

require_once 'NPKDataExtractor.php';

echo "=== NPK Data Extractor - Test & Validering ===\n\n";

try {
    // Opprett extractor med debug
    $extractor = new NPKDataExtractor(true);
    
    // Test 1: Autentisering
    echo "🔐 TEST 1: Autentisering\n";
    $authResult = $extractor->authenticate();
    echo "Resultat: " . ($authResult ? "✅ SUKSESS" : "❌ FEIL") . "\n\n";
    
    if (!$authResult) {
        throw new Exception("Autentisering feilet - kan ikke fortsette tester");
    }
    
    // Test 2: Hent valpeliste
    echo "📡 TEST 2: Valpeliste API\n";
    $valpeliste = $extractor->getValpeliste();
    echo "Antall kull: " . count($valpeliste['dogs']) . "\n";
    echo "Total count fra API: " . $valpeliste['totalCount'] . "\n\n";
    
    // Test 3: Elite-status for testdata
    echo "🐕 TEST 3: Elite-status oppslag (testdata)\n";
    $testHunder = [
        'NO34007/19' => 'Langlandsmoens Kevlar',
        'NO58331/21' => 'Rypeparadiset\'s Cacciatore', 
        'NO43818/19' => 'Myrteigen\'s Snuppa',
        'NO38101/17' => 'Østagløtten\'s Albin'
    ];
    
    $eliteCount = 0;
    foreach ($testHunder as $reg => $navn) {
        $elite = $extractor->getEliteStatus($reg);
        $eliteStatus = $elite['eliteh'] === '1' ? 'ELITE' : ($elite['eliteh'] === '0' ? 'IKKE-ELITE' : 'UKJENT');
        $avlStatus = $elite['avlsh'] === '1' ? 'AVL' : ($elite['avlsh'] === '0' ? 'IKKE-AVL' : 'UKJENT');
        
        echo "  {$navn} ({$reg}): {$eliteStatus}, {$avlStatus}\n";
        if ($elite['eliteh'] === '1') $eliteCount++;
    }
    echo "Elite-hunder funnet: {$eliteCount}/4\n\n";
    
    // Test 4: Komplett datasett
    echo "🏗️ TEST 4: Komplett datasett\n";
    $datasett = $extractor->buildCompleteDataset();
    
    echo "Metadata:\n";
    echo "  Ekstraksjonstidspunkt: " . $datasett['metadata']['ekstraksjonstidspunkt'] . "\n";
    echo "  Antall kull: " . $datasett['metadata']['antall_kull'] . "\n";
    echo "  Kilde: " . $datasett['metadata']['kilde'] . "\n";
    
    echo "\nStatistikk:\n";
    $stats = $datasett['statistikk'];
    if (isset($stats['elite_analyse'])) {
        $elite = $stats['elite_analyse'];
        echo "  Elite mødre: " . ($elite['elite_modre'] ?? 0) . "\n";
        echo "  Elite fedre: " . ($elite['elite_fedre'] ?? 0) . "\n";
        echo "  Avl mødre: " . ($elite['avl_modre'] ?? 0) . "\n";
        echo "  Avl fedre: " . ($elite['avl_fedre'] ?? 0) . "\n";
    }
    if (isset($stats['godkjenning_analyse'])) {
        echo "  Godkjente kull: " . ($stats['godkjenning_analyse']['godkjent'] ?? 0) . "\n";
    }
    
    echo "\nKull oversikt:\n";
    foreach ($datasett['kull'] as $index => $kull) {
        $kullId = $kull['kull_info']['kull_id'];
        $kennel = $kull['oppdretter']['kennel'];
        $farElite = $kull['far']['elitehund'] ? '⭐' : '';
        $morElite = $kull['mor']['elitehund'] ? '⭐' : '';
        $godkjent = $kull['kull_info']['godkjent_avlskriterier'] ? '✅' : '';
        
        echo "  Kull {$kullId}: {$kennel} {$godkjent}\n";
        echo "    Far: {$kull['far']['navn']} {$farElite}\n";
        echo "    Mor: {$kull['mor']['navn']} {$morElite}\n";
    }
    
    // Test 5: JSON eksport
    echo "\n📁 TEST 5: JSON eksport\n";
    $filename = $extractor->exportJson('test_export.json');
    $filesize = filesize($filename);
    echo "Fil: {$filename}\n";
    echo "Størrelse: " . number_format($filesize) . " bytes\n";
    
    // Validere JSON
    $jsonContent = file_get_contents($filename);
    $parsed = json_decode($jsonContent, true);
    $jsonValid = json_last_error() === JSON_ERROR_NONE;
    echo "JSON gyldig: " . ($jsonValid ? "✅ JA" : "❌ NEI") . "\n";
    
    if ($jsonValid) {
        echo "JSON struktur OK: " . (isset($parsed['metadata'], $parsed['kull'], $parsed['statistikk']) ? "✅ JA" : "❌ NEI") . "\n";
    }
    
    echo "\n=== ALLE TESTER FULLFØRT ===\n";
    echo "✅ NPK Data Extractor fungerer som forventet\n";
    echo "📁 Eksportert fil: {$filename}\n";
    
} catch (Exception $e) {
    echo "\n❌ TEST FEIL: " . $e->getMessage() . "\n";
    exit(1);
}
?>
