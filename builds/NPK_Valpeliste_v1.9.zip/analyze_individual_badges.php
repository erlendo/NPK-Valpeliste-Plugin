<?php
/**
 * Analyze individual dog badge data structure
 */

echo "=== Analysering av Individuelle Badge Data ===\n\n";

$login_url = 'https://pointer.datahound.no/admin';
$login_action_url = 'https://pointer.datahound.no/admin/index/auth';
$username = 'demo';
$password = 'demo';

// Initialize cURL
$ch = curl_init();

// Authentication
curl_setopt_array($ch, [
    CURLOPT_URL => $login_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => '/tmp/cookies.txt',
    CURLOPT_COOKIEFILE => '/tmp/cookies.txt',
    CURLOPT_USERAGENT => 'NPK Valpeliste Test',
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_VERBOSE => false
]);

$login_page = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($http_code == 200) {
    // Look for CSRF token
    $csrf_token = '';
    if (preg_match('/<input[^>]*name=["\']_token["\'][^>]*value=["\']([^"\']*)["\']/', $login_page, $matches)) {
        $csrf_token = $matches[1];
    }

    // Login
    $login_data = http_build_query([
        'admin_username' => $username,
        'admin_password' => $password,
        'login' => 'login',
        '_token' => $csrf_token,
        'csrf_token' => $csrf_token
    ]);

    curl_setopt_array($ch, [
        CURLOPT_URL => $login_action_url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $login_data,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
            'Referer: ' . $login_url,
            'Origin: https://pointer.datahound.no'
        ]
    ]);

    $login_response = curl_exec($ch);
    $login_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $login_successful = false;
    if ($login_http_code == 302 || $login_http_code == 301) {
        $login_successful = true;
    } elseif (strpos($login_response, 'dashboard') !== false || 
              strpos($login_response, 'admin') !== false ||
              strpos($login_response, 'logout') !== false) {
        $login_successful = true;
    }

    if ($login_successful) {
        echo "✅ Autentisering vellykket\n\n";
        
        // Get main API data
        curl_setopt_array($ch, [
            CURLOPT_URL => 'https://pointer.datahound.no/admin/product/getvalpeliste',
            CURLOPT_POST => false,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Referer: https://pointer.datahound.no/admin/'
            ]
        ]);
        
        $api_response = curl_exec($ch);
        $api_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($api_http_code == 200) {
            $data = json_decode($api_response, true);
            
            if ($data && isset($data['dogs'])) {
                echo "Fant " . count($data['dogs']) . " kull i systemet\n\n";
                
                // Analyze Wild Desert Storm litter specifically
                foreach ($data['dogs'] as $index => $dog) {
                    if (isset($dog['FatherName']) && stripos($dog['FatherName'], 'Wild Desert Storm') !== false) {
                        echo "=== WILD DESERT STORM KULL ANALYSE ===\n";
                        echo "KUID: " . ($dog['KUID'] ?? 'N/A') . "\n";
                        echo "Kennel: " . ($dog['kennel'] ?? 'N/A') . "\n";
                        echo "Far: " . ($dog['FatherName'] ?? 'N/A') . "\n";
                        echo "Far Reg: " . ($dog['father'] ?? 'N/A') . "\n";
                        echo "Mor: " . ($dog['MotherName'] ?? 'N/A') . "\n";
                        echo "Mor Reg: " . ($dog['mother'] ?? 'N/A') . "\n\n";
                        
                        echo "KULL-LEVEL BADGES (det vi nå har):\n";
                        echo "avlsh: '" . ($dog['avlsh'] ?? '') . "' (gjelder dette kullet?)\n";
                        echo "eliteh: '" . ($dog['eliteh'] ?? '') . "' (gjelder dette kullet?)\n\n";
                        
                        echo "MULIGE INDIVIDUELLE BADGE FELTER:\n";
                        $individual_fields = [];
                        foreach ($dog as $field => $value) {
                            // Look for fields that might contain individual badges
                            if (preg_match('/(father|mother|F|M).*?(avl|elite|badge)/i', $field) || 
                                preg_match('/(avl|elite|badge).*(father|mother|F|M)/i', $field)) {
                                $individual_fields[$field] = $value;
                                echo "  {$field}: '{$value}'\n";
                            }
                        }
                        
                        if (empty($individual_fields)) {
                            echo "  Ingen åpenbare individuelle badge-felter funnet!\n";
                        }
                        
                        echo "\nALLE FELT SOM INNEHOLDER 'elite' ELLER 'avl':\n";
                        foreach ($dog as $field => $value) {
                            if (stripos($field, 'elite') !== false || stripos($field, 'avl') !== false) {
                                echo "  {$field}: '{$value}'\n";
                            }
                        }
                        
                        // Check if we need to make separate API calls for individual dogs
                        echo "\n=== TESTE SEPARATE API KALL FOR INDIVIDUELLE HUNDER ===\n";
                        
                        $father_reg = $dog['father'] ?? '';
                        $mother_reg = $dog['mother'] ?? '';
                        
                        if ($father_reg) {
                            echo "Tester API for far: {$father_reg}\n";
                            
                            // Try different possible endpoints for individual dog data
                            $test_urls = [
                                "https://pointer.datahound.no/admin/product/getdog?reg={$father_reg}",
                                "https://pointer.datahound.no/admin/dog?reg={$father_reg}",
                                "https://pointer.datahound.no/admin/product/dogdetails?reg={$father_reg}",
                                "https://pointer.datahound.no/admin/product/doginfo?id={$father_reg}"
                            ];
                            
                            foreach ($test_urls as $test_url) {
                                curl_setopt($ch, CURLOPT_URL, $test_url);
                                $test_response = curl_exec($ch);
                                $test_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                                
                                echo "  {$test_url}: HTTP {$test_status}";
                                if ($test_status == 200 && !empty($test_response)) {
                                    $test_data = json_decode($test_response, true);
                                    if ($test_data) {
                                        echo " - Gyldig JSON response!";
                                        echo " (Keys: " . implode(', ', array_keys($test_data)) . ")";
                                    } else {
                                        echo " - Ikke JSON (len: " . strlen($test_response) . ")";
                                    }
                                }
                                echo "\n";
                            }
                        }
                        
                        break;
                    }
                }
                
                // Look for pattern across all dogs
                echo "\n=== BADGE PATTERN ANALYSE PÅ TVERS AV ALLE KULL ===\n";
                $all_badge_fields = [];
                foreach ($data['dogs'] as $dog) {
                    foreach ($dog as $field => $value) {
                        if (stripos($field, 'elite') !== false || 
                            stripos($field, 'avl') !== false ||
                            preg_match('/(father|mother).*badge/i', $field) ||
                            preg_match('/badge.*(father|mother)/i', $field)) {
                            
                            if (!isset($all_badge_fields[$field])) {
                                $all_badge_fields[$field] = [];
                            }
                            $all_badge_fields[$field][] = $value;
                        }
                    }
                }
                
                echo "Badge-relaterte felter funnet på tvers av alle kull:\n";
                foreach ($all_badge_fields as $field => $values) {
                    $unique_values = array_unique($values);
                    echo "  {$field}: " . implode(', ', $unique_values) . "\n";
                }
                
            } else {
                echo "❌ Ingen kull-data i API responsen\n";
            }
        } else {
            echo "❌ API kall feilet med status: {$api_http_code}\n";
        }
    } else {
        echo "❌ Autentisering feilet\n";
    }
} else {
    echo "❌ Innloggingsside ikke tilgjengelig\n";
}

curl_close($ch);
echo "\n=== Analyse Fullført ===\n";
?>
