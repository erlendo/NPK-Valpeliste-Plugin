<?php
echo "=== Søker etter spesifikke Kull-IDer ===\n\n";

// Første - logg inn
$login_url = 'https://pointer.datahound.no/admin';
$login_action_url = 'https://pointer.datahound.no/admin/index/auth';

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $login_url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_COOKIEJAR, '/tmp/cookies.txt');
curl_setopt($curl, CURLOPT_COOKIEFILE, '/tmp/cookies.txt');
$login_page = curl_exec($curl);

// Hent CSRF token
preg_match('/name="_token" value="([^"]*)"/', $login_page, $token_match);
$csrf_token = $token_match[1] ?? '';

// Logg inn
curl_setopt($curl, CURLOPT_URL, $login_action_url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query([
    'username' => 'demo',
    'password' => 'demo',
    '_token' => $csrf_token
]));
curl_setopt($curl, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded',
    'Referer: ' . $login_url,
    'Origin: https://pointer.datahound.no'
]);
curl_exec($curl);

// Hent valpeliste data
$api_url = 'https://pointer.datahound.no/admin/product/getvalpeliste';
curl_setopt($curl, CURLOPT_URL, $api_url);
curl_setopt($curl, CURLOPT_POST, false);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
    'Accept: application/json, text/javascript, */*; q=0.01',
    'X-Requested-With: XMLHttpRequest',
    'Referer: https://pointer.datahound.no/admin/'
]);

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($http_code !== 200) {
    echo "API feil: HTTP $http_code\n";
    exit;
}

$data = json_decode($response, true);
if (!$data || !isset($data['dogs'])) {
    echo "Ugyldig API respons\n";
    exit;
}

$target_kuids = [2332, 2340, 2339, 2341, 2338];
$found_kuids = [];

echo "Søker etter KUID: " . implode(', ', $target_kuids) . "\n\n";

foreach ($data['dogs'] as $index => $litter) {
    $kuid = (int)$litter['KUID'];
    
    if (in_array($kuid, $target_kuids)) {
        $found_kuids[] = $kuid;
        
        echo "✅ FUNNET - KUID: {$kuid}\n";
        echo "   Kennel: " . $litter['kennel'] . "\n";
        echo "   Far: " . $litter['FatherName'] . "\n";
        echo "   Mor: " . $litter['MotherName'] . "\n";
        echo "   Badge status:\n";
        echo "     avlsh: " . json_encode($litter['avlsh'] ?? null) . "\n";
        echo "     eliteh: " . json_encode($litter['eliteh'] ?? null) . "\n";
        echo "   Premie scores:\n";
        echo "     Far premie: " . json_encode($litter['premie'] ?? null) . "\n";
        echo "     Mor premie: " . json_encode($litter['PremieM'] ?? null) . "\n";
        echo "\n" . str_repeat("-", 50) . "\n\n";
    }
}

echo "=== SAMMENDRAG ===\n";
echo "Søkte etter: " . count($target_kuids) . " kull-IDer\n";
echo "Funnet: " . count($found_kuids) . " kull-IDer\n";

$missing_kuids = array_diff($target_kuids, $found_kuids);
if (!empty($missing_kuids)) {
    echo "Manglende: " . implode(', ', $missing_kuids) . "\n";
} else {
    echo "✅ ALLE kull-IDer funnet!\n";
}

echo "\nFunnet KUIDs: " . implode(', ', $found_kuids) . "\n";
?>
