<?php
// Debug badge data directly
require_once 'NPKDataExtractorLive.php';

$extractor = new NPKDataExtractorLive(true); // Enable debug

// Get one litter data
$data = $extractor->getLiveData();

if (isset($data['error'])) {
    echo "<h2>Error:</h2>";
    echo "<pre>" . $data['error'] . "</pre>";
} else {
    echo "<h2>Badge Debug Test</h2>";
    
    if (isset($data['kull']) && !empty($data['kull'])) {
        $kull = $data['kull'][0]; // First litter
        
        echo "<h3>Kull ID: " . $kull['kull_info']['KUID'] . "</h3>";
        
        echo "<h4>Mor Data:</h4>";
        echo "<pre>";
        var_dump($kull['mor']);
        echo "</pre>";
        
        echo "<h4>Far Data:</h4>";
        echo "<pre>";
        var_dump($kull['far']);
        echo "</pre>";
        
        echo "<h4>Badge Display Test:</h4>";
        if (isset($kull['mor']['elitehund']) && $kull['mor']['elitehund']) {
            echo '<span class="valpeliste-badge elitehund">Elitehund</span> ';
        }
        if (isset($kull['mor']['avlshund']) && $kull['mor']['avlshund']) {
            echo '<span class="valpeliste-badge avlshund">Avlshund</span> ';
        }
        
        echo "<br><br>";
        
        if (isset($kull['far']['elitehund']) && $kull['far']['elitehund']) {
            echo '<span class="valpeliste-badge elitehund">Elitehund</span> ';
        }
        if (isset($kull['far']['avlshund']) && $kull['far']['avlshund']) {
            echo '<span class="valpeliste-badge avlshund">Avlshund</span> ';
        }
    }
}
?>

<style>
.valpeliste-badge {
    display: inline-block;
    padding: 2px 6px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    vertical-align: middle;
    margin-left: 4px;
    line-height: 1.2;
}

.valpeliste-badge.avlshund {
    background-color: #FF9800;
    color: white;
}

.valpeliste-badge.elitehund {
    background-color: #4CAF50;
    color: white;
}
</style>
