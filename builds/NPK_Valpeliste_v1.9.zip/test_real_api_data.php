<?php
/**
 * Test for å se hva vi faktisk får fra Datahound API
 */

// Definer ABSPATH for å unngå security check
if (!defined('ABSPATH')) {
    define('ABSPATH', '/fake/path/');
}

// Mock WordPress funksjoner
if (!function_exists('get_option')) {
    function get_option($option, $default = false) {
        return $default;
    }
}

// Include plugin filer
require_once 'npk_valpeliste.php';

echo "<h2>Faktisk Data Fra Datahound API</h2>\n";

echo "<h3>1. Test autentisering</h3>\n";
if (function_exists('authenticate_datahound')) {
    $auth_result = authenticate_datahound();
    if ($auth_result) {
        echo "✅ Autentisering vellykket\n";
        
        echo "<h3>2. Hent ekte API data</h3>\n";
        if (function_exists('fetch_valpeliste_data')) {
            $api_data = fetch_valpeliste_data();
            
            if ($api_data && isset($api_data['dogs']) && !empty($api_data['dogs'])) {
                echo "✅ API data hentet: " . count($api_data['dogs']) . " kull\n\n";
                
                echo "<h3>3. Vis første 3 kull fra API (rå data)</h3>\n";
                for ($i = 0; $i < min(3, count($api_data['dogs'])); $i++) {
                    echo "<h4>Kull " . ($i + 1) . ":</h4>\n";
                    echo "<pre>";
                    print_r($api_data['dogs'][$i]);
                    echo "</pre>";
                    echo "<hr>\n";
                }
                
                echo "<h3>4. Søk etter spesifikke hunder vi kjenner</h3>\n";
                
                $found_wild_desert = false;
                $found_philippa = false;
                $found_cacciatore = false;
                
                foreach ($api_data['dogs'] as $index => $dog) {
                    // Sjekk for Wild Desert Storm
                    if (isset($dog['FatherName']) && stripos($dog['FatherName'], 'Wild Desert Storm') !== false) {
                        echo "<h4>✅ FUNNET: Wild Desert Storm (som far)</h4>\n";
                        echo "<pre>";
                        print_r($dog);
                        echo "</pre>";
                        $found_wild_desert = true;
                    }
                    
                    // Sjekk for Philippa
                    if (isset($dog['MotherName']) && stripos($dog['MotherName'], 'Philippa') !== false) {
                        echo "<h4>✅ FUNNET: Philippa (som mor)</h4>\n";
                        echo "<pre>";
                        print_r($dog);
                        echo "</pre>";
                        $found_philippa = true;
                    }
                    
                    // Sjekk for Cacciatore
                    if (isset($dog['FatherName']) && stripos($dog['FatherName'], 'Cacciatore') !== false) {
                        echo "<h4>✅ FUNNET: Cacciatore (som far)</h4>\n";
                        echo "<pre>";
                        print_r($dog);
                        echo "</pre>";
                        $found_cacciatore = true;
                    }
                }
                
                if (!$found_wild_desert) {
                    echo "❌ Wild Desert Storm ikke funnet i API data\n";
                }
                if (!$found_philippa) {
                    echo "❌ Philippa ikke funnet i API data\n";
                }
                if (!$found_cacciatore) {
                    echo "❌ Cacciatore ikke funnet i API data\n";
                }
                
                echo "<h3>5. Feltanalyse - hva finnes i API data?</h3>\n";
                $first_dog = $api_data['dogs'][0];
                echo "Alle felt i første hund:\n";
                echo "<pre>";
                foreach ($first_dog as $key => $value) {
                    echo "$key: " . (is_string($value) ? substr($value, 0, 100) : $value) . "\n";
                }
                echo "</pre>";
                
                // Sjekk spesifikt etter badge-relaterte felt
                echo "<h3>6. Badge-relaterte felt i API</h3>\n";
                $badge_fields = ['avlsh', 'eliteh', 'avlshF', 'avlshM', 'elitehF', 'elitehM'];
                foreach ($api_data['dogs'] as $index => $dog) {
                    echo "<h4>Kull " . ($index + 1) . " badge felt:</h4>\n";
                    foreach ($badge_fields as $field) {
                        if (isset($dog[$field])) {
                            echo "$field: " . $dog[$field] . "\n";
                        } else {
                            echo "$field: ikke satt\n";
                        }
                    }
                    echo "<br>";
                    
                    if ($index >= 2) break; // Kun første 3 kull
                }
                
            } else {
                echo "❌ Kunne ikke hente API data\n";
                echo "API respons:\n";
                echo "<pre>";
                var_dump($api_data);
                echo "</pre>";
            }
        } else {
            echo "❌ fetch_valpeliste_data funksjonen ikke funnet\n";
        }
    } else {
        echo "❌ Autentisering feilet\n";
    }
} else {
    echo "❌ authenticate_datahound funksjonen ikke funnet\n";
}

?>
