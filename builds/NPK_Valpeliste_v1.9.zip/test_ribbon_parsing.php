<?php
/**
 * Test enhanced ribbon parsing
 */

echo "=== NPK Valpeliste Enhanced Ribbon Test ===\n\n";

// Simple ribbon parsing function (standalone)
function test_parse_premium_ribbons($ribbon_html) {
    if (empty($ribbon_html)) {
        return '';
    }
    
    $output = '';
    
    // Extract all img tags from the ribbon HTML
    if (preg_match_all('/<img[^>]*>/i', $ribbon_html, $matches)) {
        foreach ($matches[0] as $img_tag) {
            // Extract tooltip text
            $tooltip = '';
            if (preg_match('/qtip=["\']([^"\']*)["\']/', $img_tag, $qtip_matches)) {
                $tooltip = $qtip_matches[1];
            }
            
            // Extract image source
            $src = '';
            if (preg_match('/src=["\']([^"\']*)["\']/', $img_tag, $src_matches)) {
                $src = $src_matches[1];
                
                // Convert relative URLs to absolute URLs for Datahound domain
                if (strpos($src, '/') === 0) {
                    $src = 'https://pointer.datahound.no' . $src;
                }
            }
            
            // Determine badge type from image source or tooltip
            $badge_class = 'ribbon-badge';
            $badge_text = $tooltip;
            
            if (stripos($src, 'ribbon_red') !== false || stripos($tooltip, 'utstilling') !== false) {
                $badge_class .= ' ribbon-exhibition';
                if (empty($badge_text)) $badge_text = 'Utstillingspremie';
            } elseif (stripos($src, 'ribbon_darkblue') !== false || stripos($tooltip, 'jakt') !== false) {
                $badge_class .= ' ribbon-hunt';
                if (empty($badge_text)) $badge_text = 'Jaktpremie';
            }
            
            // Create enhanced ribbon display
            if (!empty($src)) {
                $output .= '<span class="' . htmlspecialchars($badge_class, ENT_QUOTES) . '" title="' . htmlspecialchars($badge_text, ENT_QUOTES) . '">';
                $output .= '<img src="' . htmlspecialchars($src, ENT_QUOTES) . '" alt="' . htmlspecialchars($badge_text, ENT_QUOTES) . '" class="ribbon-image" />';
                $output .= '<span class="ribbon-text">' . htmlspecialchars($badge_text, ENT_QUOTES) . '</span>';
                $output .= '</span>';
            }
        }
    }
    
    return $output;
}

// Test with real API data examples
$test_ribbons = array(
    'Father with ribbons' => '<img id="utsimg" qtip="Utstillingspremie" src="/images/shops/ribbon_red.gif"> <img qtip="Jaktpremie" src="/images/shops/ribbon_darkblue.gif">',
    'Mother with ribbons' => '<img id="utsimg" qtip="Utstillingspremie" src="/images/shops/ribbon_red.gif"> <img qtip="Jaktpremie" src="/images/shops/ribbon_darkblue.gif">',
    'Single ribbon' => '<img id="utsimg" qtip="Utstillingspremie" src="/images/shops/ribbon_red.gif">',
    'Empty string' => '',
    'Real data example' => '<img id="utsimg" qtip="Utstillingspremie" src="/images/shops/ribbon_red.gif"> <img qtip="Jaktpremie"'
);

foreach ($test_ribbons as $test_name => $ribbon_html) {
    echo "=== Test: $test_name ===\n";
    echo "Input HTML: " . ($ribbon_html ? $ribbon_html : '(empty)') . "\n";
    
    $result = test_parse_premium_ribbons($ribbon_html);
    echo "Processed Output:\n";
    echo $result ? $result : '(empty result)';
    echo "\n\n";
}

echo "=== Test Complete ===\n";
