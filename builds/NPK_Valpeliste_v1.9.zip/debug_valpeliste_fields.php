<?php
/**
 * Debug valpeliste structure to find registration number fields
 */

require_once 'NPKDataExtractorLive.php';

echo "=== DEBUG VALPELISTE STRUKTUR ===\n\n";

$extractor = new NPKDataExtractorLive(true);

if (!$extractor->authenticate()) {
    echo "❌ Auth failed\n";
    exit;
}

$valpeliste = $extractor->getValpeliste();

if (isset($valpeliste['error'])) {
    echo "❌ Valpeliste error: " . $valpeliste['error'] . "\n";
    exit;
}

if (isset($valpeliste['dogs']) && !empty($valpeliste['dogs'])) {
    $firstLitter = $valpeliste['dogs'][0];
    
    echo "=== FØRSTE KULL ALLE FELTER ===\n";
    foreach ($firstLitter as $key => $value) {
        $displayValue = is_string($value) ? $value : (is_array($value) ? '[array]' : $value);
        echo "$key: $displayValue\n";
    }
    
    echo "\n=== SØKER ETTER REGISTRERINGSNUMMER FELTER ===\n";
    
    $regno_fields = [];
    foreach ($firstLitter as $key => $value) {
        if (stripos($key, 'regno') !== false || 
            stripos($key, 'regist') !== false ||
            stripos($key, 'reg') !== false ||
            stripos($key, 'mother') !== false ||
            stripos($key, 'father') !== false) {
            $regno_fields[$key] = $value;
        }
    }
    
    echo "Mulige registreringsnummer felter:\n";
    foreach ($regno_fields as $key => $value) {
        echo "$key: $value\n";
    }
    
    // Sjekk for prefix/pattern
    echo "\n=== ANALYSE AV VERDIER ===\n";
    foreach ($regno_fields as $key => $value) {
        if (preg_match('/^NO\d+\/\d+$/', $value)) {
            echo "✅ $key: '$value' - Ser ut som gyldig norsk registreringsnummer\n";
        } else {
            echo "❓ $key: '$value' - Ukjent format\n";
        }
    }
} else {
    echo "❌ Ingen kull funnet i valpeliste\n";
}

?>
