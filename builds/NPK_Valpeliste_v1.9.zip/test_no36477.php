<?php
/**
 * Test spesifikk hund NO36477/22 med eksakt URL du ga
 */

echo "=== Test Hund NO36477/22 ===\n\n";

$cookieJar = tempnam(sys_get_temp_dir(), 'test_cookies');

// Login
echo "Logger inn...\n";
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'https://pointer.datahound.no/admin',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEJAR => $cookieJar,
    CURLOPT_COOKIEFILE => $cookieJar,
    CURLOPT_USERAGENT => 'Mozilla/5.0',
    CURLOPT_SSL_VERIFYPEER => false
]);
curl_exec($ch);
curl_close($ch);

// Auth med korrekte feltnavn
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'https://pointer.datahound.no/admin/index/auth',
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => 'admin_username=demo&admin_password=demo&login=login',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_COOKIEJAR => $cookieJar,
    CURLOPT_COOKIEFILE => $cookieJar,
    CURLOPT_USERAGENT => 'Mozilla/5.0',
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Auth HTTP Code: $httpCode\n";

if ($httpCode !== 302) {
    echo "❌ Login feilet - HTTP $httpCode\n";
    echo "Response: " . substr($response, 0, 200) . "\n";
    exit;
}

echo "✅ Login OK\n\n";

// Test eksakt URL
$url = 'https://pointer.datahound.no/admin/product/getdog?id=NO36477/22';
echo "Testing: $url\n";

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_COOKIEFILE => $cookieJar,
    CURLOPT_USERAGENT => 'Mozilla/5.0',
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Accept: application/json']
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP: $httpCode\n";
echo "Response:\n";

if ($httpCode === 200) {
    $data = json_decode($response, true);
    if ($data) {
        echo "JSON Data:\n";
        print_r($data);
    } else {
        echo "Raw response:\n$response\n";
    }
} else {
    echo "Error response:\n$response\n";
}

unlink($cookieJar);
?>
