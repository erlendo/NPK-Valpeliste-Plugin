<?php
/**
 * Test den nye npk_valpeliste shortcoden med riktig UI struktur - Uten WordPress
 */

// Mock WordPress funksjoner for testing
function esc_html($text) { return htmlspecialchars($text); }
function wp_kses_post($text) { return $text; }

// Inkluder bare funksjonen vi trenger
function npk_display_valpeliste_from_data($data) {
    // Start container med samme struktur som den gamle
    $html = '<div class="valpeliste-container"><div class="valpeliste-card-container">';
    
    // Metadata header
    $html .= '<div class="npk-metadata">';
    $html .= '<p>Oppdatert: ' . date('d.m.Y H:i', strtotime($data['metadata']['ekstraksjonstidspunkt'])) . '</p>';
    $html .= '<p>Antall kull: ' . $data['metadata']['antall_kull'] . '</p>';
    $html .= '</div>';
    
    $html .= '<h2 class="valpeliste-section-title approved">NPK Valpeliste</h2>';
    $html .= '<div class="valpeliste-card-group">';
    
    foreach ($data['kull'] as $kull) {
        // Bruk samme card struktur som den gamle
        $html .= '<div class="valpeliste-card approved">';
        
        // Card top section
        $html .= '<div class="valpeliste-card-top">';
        
        // Header info
        $html .= '<div class="valpeliste-card-header">';
        $html .= '<h3>' . esc_html($kull['oppdretter']['kennel']) . '</h3>';
        $html .= '<span class="valpeliste-date">Forventet: ' . esc_html($kull['kull_info']['fodt']) . '</span>';
        $html .= '</div>';
        
        // Contact info
        $html .= '<div class="valpeliste-info">';
        $html .= '<div class="valpeliste-info-inner">';
        $html .= '<div class="valpeliste-info-row"><span class="valpeliste-label">Oppdretter:</span> ' . esc_html($kull['oppdretter']['navn']) . '</div>';
        $html .= '<div class="valpeliste-info-row"><span class="valpeliste-label">Sted:</span> ' . esc_html($kull['oppdretter']['sted'] ?? 'Ikke oppgitt') . '</div>';
        if (!empty($kull['oppdretter']['kontakt']['telefon'])) {
            $html .= '<div class="valpeliste-info-row"><span class="valpeliste-label">Telefon:</span> ' . esc_html($kull['oppdretter']['kontakt']['telefon']) . '</div>';
        }
        if (!empty($kull['oppdretter']['kontakt']['epost'])) {
            $html .= '<div class="valpeliste-info-row"><span class="valpeliste-label">E-post:</span> ' . esc_html($kull['oppdretter']['kontakt']['epost']) . '</div>';
        }
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        
        // Card body content
        $html .= '<div class="valpeliste-card-body">';
        $html .= '<div class="valpeliste-parents">';
        
        // Far (same structure as old)
        $html .= '<div class="valpeliste-parent-row">';
        $html .= '<span class="valpeliste-label">Far:</span> ';
        $html .= '<span class="valpeliste-parent-info">';
        $html .= '<span class="valpeliste-value">' . esc_html($kull['far']['navn']);
        if (!empty($kull['far']['registreringsnummer'])) {
            $html .= ' (' . esc_html($kull['far']['registreringsnummer']) . ')';
        }
        $html .= '</span>';
        
        // Father badges
        $father_badges = '';
        if ($kull['far']['elitehund']) {
            $father_badges .= '<span class="valpeliste-badge elitehund">Elitehund</span>';
        }
        if ($kull['far']['avlshund']) {
            $father_badges .= '<span class="valpeliste-badge avlshund">Avlshund</span>';
        }
        if (!empty($father_badges)) {
            $html .= ' ' . $father_badges;
        }
        $html .= '</span>';
        $html .= '</div>';
        
        // Father details (samme struktur som den gamle)
        if (isset($kull['far']['detaljer']) && !empty($kull['far']['detaljer'])) {
            $html .= '<ul class="valpeliste-parent-details">';
            foreach ($kull['far']['detaljer'] as $key => $value) {
                if (!empty($value)) {
                    $html .= '<li><strong>' . esc_html($key) . ':</strong> ' . esc_html($value) . '</li>';
                }
            }
            $html .= '</ul>';
        }
        
        // Mor (same structure as old)
        $html .= '<div class="valpeliste-parent-row">';
        $html .= '<span class="valpeliste-label">Mor:</span> ';
        $html .= '<span class="valpeliste-parent-info">';
        $html .= '<span class="valpeliste-value">' . esc_html($kull['mor']['navn']);
        if (!empty($kull['mor']['registreringsnummer'])) {
            $html .= ' (' . esc_html($kull['mor']['registreringsnummer']) . ')';
        }
        $html .= '</span>';
        
        // Mother badges
        $mother_badges = '';
        if ($kull['mor']['elitehund']) {
            $mother_badges .= '<span class="valpeliste-badge elitehund">Elitehund</span>';
        }
        if ($kull['mor']['avlshund']) {
            $mother_badges .= '<span class="valpeliste-badge avlshund">Avlshund</span>';
        }
        if (!empty($mother_badges)) {
            $html .= ' ' . $mother_badges;
        }
        $html .= '</span>';
        $html .= '</div>';
        
        // Mother details
        if (isset($kull['mor']['detaljer']) && !empty($kull['mor']['detaljer'])) {
            $html .= '<ul class="valpeliste-parent-details">';
            foreach ($kull['mor']['detaljer'] as $key => $value) {
                if (!empty($value)) {
                    $html .= '<li><strong>' . esc_html($key) . ':</strong> ' . esc_html($value) . '</li>';
                }
            }
            $html .= '</ul>';
        }
        
        $html .= '</div>'; // End parents
        
        // Annonsetekst (som i den gamle)
        if (!empty($kull['annonse_tekst'])) {
            $html .= '<div class="valpeliste-announcement">';
            $html .= '<h4>Annonse:</h4>';
            $html .= '<p>' . wp_kses_post($kull['annonse_tekst']) . '</p>';
            $html .= '</div>';
        }
        
        $html .= '</div>'; // End card body
        $html .= '</div>'; // End card
    }
    
    $html .= '</div>'; // End card group
    $html .= '</div></div>'; // End containers
    
    return $html;
}

echo "<h1>Test av ny NPK shortcode struktur</h1>";

// Simuler et lite datasett for testing
$test_data = [
    'metadata' => [
        'ekstraksjonstidspunkt' => date('c'),
        'antall_kull' => 1,
        'kilde' => 'Test Data'
    ],
    'kull' => [
        [
            'kull_info' => [
                'KUID' => 'TEST123',
                'fodt' => '2025-02-15'
            ],
            'oppdretter' => [
                'navn' => 'Test Oppdretter',
                'kennel' => 'Test Kennel',
                'sted' => 'Oslo',
                'kontakt' => [
                    'telefon' => '12345678',
                    'epost' => 'test@test.no'
                ]
            ],
            'far' => [
                'navn' => 'Test Far',
                'registreringsnummer' => 'N12345',
                'elitehund' => true,
                'avlshund' => false
            ],
            'mor' => [
                'navn' => 'Test Mor', 
                'registreringsnummer' => 'N54321',
                'elitehund' => false,
                'avlshund' => true
            ],
            'annonse_tekst' => 'Dette er en test annonse for kullet.'
        ]
    ]
];

echo "<h2>Generert HTML:</h2>";
echo "<pre>";
echo htmlspecialchars(npk_display_valpeliste_from_data($test_data));
echo "</pre>";

echo "<h2>Preview:</h2>";
echo npk_display_valpeliste_from_data($test_data);

echo "<h2>✅ Forbedringer implementert:</h2>";
echo "<ul>";
echo "<li>✅ Samme valpeliste-container og valpeliste-card klasser som den gamle</li>";
echo "<li>✅ Riktig contact info struktur med telefon og epost</li>";
echo "<li>✅ Badge display for mor og far med riktige klasser</li>";
echo "<li>✅ Annonsetekst med riktig HTML struktur</li>";
echo "<li>✅ Parent details struktur (klargjort for fremtidige data)</li>";
echo "<li>✅ Card header med kennel og dato</li>";
echo "<li>✅ Oppdretter, sted og kontaktinfo</li>";
echo "</ul>";

echo "<p><strong>Neste steg:</strong> Bygg ny versjon og test med [npk_valpeliste] shortcode i WordPress!</p>";

?>
