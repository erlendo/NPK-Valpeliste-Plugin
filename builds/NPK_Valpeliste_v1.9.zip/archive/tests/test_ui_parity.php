<?php
/**
 * Test den nye npk_valpeliste shortcoden med riktig UI struktur
 */

// Include WordPress for testing
require_once('live_display_example.php');

echo "<h1>Test av ny NPK shortcode struktur</h1>";

// Simuler et lite datasett for testing
$test_data = [
    'metadata' => [
        'ekstraksjonstidspunkt' => date('c'),
        'antall_kull' => 1,
        'kilde' => 'Test Data'
    ],
    'kull' => [
        [
            'kull_info' => [
                'KUID' => 'TEST123',
                'fodt' => '2025-02-15'
            ],
            'oppdretter' => [
                'navn' => 'Test Oppdretter',
                'kennel' => 'Test Kennel',
                'sted' => 'Oslo',
                'kontakt' => [
                    'telefon' => '12345678',
                    'epost' => 'test@test.no'
                ]
            ],
            'far' => [
                'navn' => 'Test Far',
                'registreringsnummer' => 'N12345',
                'elitehund' => true,
                'avlshund' => false
            ],
            'mor' => [
                'navn' => 'Test Mor', 
                'registreringsnummer' => 'N54321',
                'elitehund' => false,
                'avlshund' => true
            ],
            'annonse_tekst' => 'Dette er en test annonse for kullet.'
        ]
    ]
];

echo "<h2>Generert HTML:</h2>";
echo npk_display_valpeliste_from_data($test_data);

echo "<h2>Resultatet vil vise:</h2>";
echo "<ul>";
echo "<li>✅ Samme valpeliste-container klasser som den gamle</li>";
echo "<li>✅ Contact info med telefon og epost</li>";
echo "<li>✅ Badge display for mor og far</li>";
echo "<li>✅ Annonsetekst</li>";
echo "<li>✅ Samme card-struktur</li>";
echo "</ul>";

echo "<p><strong>Neste steg:</strong> Oppdater WordPress plugin og test med [npk_valpeliste] shortcode!</p>";

?>
