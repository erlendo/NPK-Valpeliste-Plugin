<?php
/**
 * Direct test of badge functions without WordPress
 */

// Definer ABSPATH for å unngå security check
if (!defined('ABSPATH')) {
    define('ABSPATH', '/fake/path/');
}

// Mock WordPress funksjoner
if (!function_exists('get_option')) {
    function get_option($option, $default = false) {
        return $default;
    }
}

// Include helper funksjoner direkte
require_once 'includes/helpers.php';
require_once 'includes/data-processing.php';

echo "<h2>Direct Badge Function Test</h2>\n";

// Test data som simulerer API response med badges
$test_valp = [
    'KUID' => '2334',
    'kennel' => 'Test Kennel',
    'FatherName' => "Huldreveien's Wild Desert Storm",
    'FatherReg' => 'NO46865/21',
    'MotherName' => 'Test Mother',
    'MotherReg' => 'NO12345/20',
    'avlsh' => '1',    // API flagg: avlshund i kullet
    'eliteh' => '1',   // API flagg: elite i kullet
    'premie' => '13',  // Fars premie score
    'PremieM' => '8',  // Mors premie score
];

echo "<h3>1. Original test data</h3>\n";
echo "<pre>";
print_r($test_valp);
echo "</pre>";

echo "<h3>2. Test convert_to_individual_structure</h3>\n";
if (function_exists('convert_to_individual_structure')) {
    $processed = convert_to_individual_structure([$test_valp]);
    
    echo "Prosessert data:\n";
    echo "<pre>";
    print_r($processed[0]);
    echo "</pre>";
    
    echo "<h3>3. Test get_dog_status for far</h3>\n";
    if (function_exists('get_dog_status')) {
        $father_status = get_dog_status($processed[0], 'father', true);
        echo "Far status:\n";
        echo "<pre>";
        print_r($father_status);
        echo "</pre>";
        
        echo "<h3>4. Test get_dog_status for mor</h3>\n";
        $mother_status = get_dog_status($processed[0], 'mother', true);
        echo "Mor status:\n";
        echo "<pre>";
        print_r($mother_status);
        echo "</pre>";
        
        echo "<h3>5. Resultater</h3>\n";
        if ($father_status['elitehund']) {
            echo "✅ Far viser som elitehund: " . $father_status['elitehund_reason'] . "\n";
        } else {
            echo "❌ Far viser IKKE som elitehund\n";
        }
        
        if ($father_status['avlshund']) {
            echo "✅ Far viser som avlshund: " . $father_status['avlshund_reason'] . "\n";
        } else {
            echo "❌ Far viser IKKE som avlshund\n";
        }
        
        if ($mother_status['elitehund']) {
            echo "✅ Mor viser som elitehund: " . $mother_status['elitehund_reason'] . "\n";
        } else {
            echo "❌ Mor viser IKKE som elitehund\n";
        }
        
    } else {
        echo "❌ get_dog_status funksjonen ikke funnet\n";
    }
} else {
    echo "❌ convert_to_individual_structure funksjonen ikke funnet\n";
}

?>
