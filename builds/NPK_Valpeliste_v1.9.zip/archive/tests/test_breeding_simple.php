<?php
/**
 * Enkel test av godkjenning av kull iht. avlskriterier (uten WordPress)
 */

require_once 'NPKDataExtractorLive.php';

echo "<h1>Test av Godkjenning av Kull iht. Avlskriterier</h1>";

// Test ekstraktoren
$extractor = new NPKDataExtractorLive(true);

echo "<h2>1. Test av isLitterApproved metode</h2>";
echo "KUID 2340: " . ($extractor->isLitterApproved(2340) ? "✅ Godkjent" : "❌ Ikke godkjent") . "<br>";
echo "KUID 2341: " . ($extractor->isLitterApproved(2341) ? "✅ Godkjent" : "❌ Ikke godkjent") . "<br>";
echo "KUID 2332: " . ($extractor->isLitterApproved(2332) ? "✅ Godkjent" : "❌ Ikke godkjent") . "<br>";

echo "<h2>2. Test av data-ekstraksjon</h2>";
if (!$extractor->authenticate()) {
    echo "❌ Kunne ikke autentisere mot NPK API<br>";
    exit;
}

$data = $extractor->buildCompleteDataset();
echo "✅ Data hentet fra API<br>";

echo "<h3>Kull med KUID og godkjenningsstatus:</h3>";
foreach ($data['kull'] as $kull) {
    $kuid = $kull['kull_info']['KUID'];
    $godkjent = isset($kull['kull_info']['godkjent_avlskriterier']) ? 
                ($kull['kull_info']['godkjent_avlskriterier'] ? "✅ Godkjent" : "❌ Ikke godkjent") : 
                "⚠️ Status ikke satt";
    
    echo "KUID {$kuid} ({$kull['oppdretter']['kennel']}): {$godkjent}<br>";
}

echo "<h2>3. Eksempel på JSON-utdata</h2>";
echo "<pre>" . json_encode($data['kull'][0]['kull_info'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";

?>
