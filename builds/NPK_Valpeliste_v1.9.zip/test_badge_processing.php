<?php
/**
 * Test badge processing for NPK Valpeliste
 */

// Mock the necessary helper functions
function get_safe_value($array, $keys, $default = '') {
    if (!is_array($keys)) {
        $keys = array($keys);
    }
    
    foreach ($keys as $key) {
        if (isset($array[$key])) {
            return $array[$key];
        }
    }
    return $default;
}

function get_dog_status($valp, $parent = 'father', $debug_mode = false) {
    $result = array(
        'avlshund' => false,
        'elitehund' => false,
        'avlshund_reason' => '',
        'elitehund_reason' => '',
    );
    
    // Simple logic to match the plugin
    $flag_field = 'avlsh'; 
    $elite_field = 'eliteh';  // API-et bruker samme felt for begge foreldre
    
    // 1. Check direct avlsh flag
    if (isset($valp[$flag_field]) && $valp[$flag_field] == '1') {
        $result['avlshund'] = true;
        $result['avlshund_reason'] = $flag_field . '="1"';
    }
    
    if (isset($valp[$elite_field]) && $valp[$elite_field] == '1') {
        $result['elitehund'] = true;
        $result['elitehund_reason'] = $elite_field . '="1"';
    }
    
    if ($debug_mode) {
        $result['debug_info'] = array(
            'avlsh' => isset($valp['avlsh']) ? $valp['avlsh'] : 'ikke satt',
            'eliteh' => isset($valp['eliteh']) ? $valp['eliteh'] : 'ikke satt',
            'parent_type' => $parent
        );
    }
    
    return $result;
}

echo "=== NPK Valpeliste Badge Processing Test ===\n\n";

// Test the mother from Black Luckys Philippa example
$mother_data = array(
    'MotherName' => 'Black Luckys Philippa',
    'avlsh' => '0',
    'eliteh' => '1'
);

echo "=== Mother Data ===\n";
print_r($mother_data);

$mother_status = get_dog_status($mother_data, 'mother', true);

echo "\n=== Mother Status Analysis ===\n";
echo "avlshund: " . ($mother_status['avlshund'] ? 'TRUE' : 'FALSE') . "\n";
echo "elitehund: " . ($mother_status['elitehund'] ? 'TRUE' : 'FALSE') . "\n";
echo "avlshund_reason: " . $mother_status['avlshund_reason'] . "\n";
echo "elitehund_reason: " . $mother_status['elitehund_reason'] . "\n";

if (isset($mother_status['debug_info'])) {
    echo "\nDebug info:\n";
    print_r($mother_status['debug_info']);
}

echo "\n=== Test Complete ===\n";
