<?php
/**
 * Quick production test for NPK system
 */

require_once 'NPKDataExtractorLive.php';

echo "=== NPK SYSTEM TEST ===\n\n";

echo "1. Testing NPKDataExtractorLive...\n";
$extractor = new NPKDataExtractorLive(false);

if (!$extractor->authenticate()) {
    echo "❌ CRITICAL: Authentication failed!\n";
    exit;
}
echo "✅ Authentication OK\n\n";

echo "2. Testing dataset building...\n";
$data = $extractor->buildCompleteDataset();

if (isset($data['error'])) {
    echo "❌ CRITICAL: Dataset error - " . $data['error'] . "\n";
    exit;
}

echo "✅ Dataset OK\n";
echo "Kull count: " . $data['metadata']['antall_kull'] . "\n";
echo "Elite mødre: " . $data['statistikk']['elite_modre'] . "\n";
echo "Elite fedre: " . $data['statistikk']['elite_fedre'] . "\n";

$totalBadges = $data['statistikk']['elite_modre'] + $data['statistikk']['elite_fedre'] + 
               $data['statistikk']['avls_modre'] + $data['statistikk']['avls_fedre'];

if ($totalBadges > 0) {
    echo "✅ Badges working: $totalBadges total\n";
} else {
    echo "❌ WARNING: No badges found\n";
}

echo "\n3. Testing shortcode functionality...\n";

// Mock WordPress functions
if (!function_exists('wp_kses_post')) {
    function wp_kses_post($text) { return strip_tags($text); }
}

require_once 'live_display_example.php';

try {
    $shortcodeData = npk_get_live_data();
    
    if (isset($shortcodeData['error'])) {
        echo "❌ Shortcode data error: " . $shortcodeData['error'] . "\n";
    } else {
        echo "✅ Shortcode data OK\n";
        echo "Shortcode ready for [npk_valpeliste]\n";
    }
} catch (Exception $e) {
    echo "❌ Shortcode error: " . $e->getMessage() . "\n";
}

echo "\n=== TEST COMPLETE ===\n";
echo "System status: " . ($totalBadges > 0 ? "✅ WORKING" : "❌ NEEDS ATTENTION") . "\n";

?>
