<?php
/**
 * Direct test of badge functions without WordPress
 */

// Definer ABSPATH for å unngå security check
if (!defined('ABSPATH')) {
    define('ABSPATH', '/fake/path/');
}

// Mock WordPress funksjoner
if (!function_exists('get_option')) {
    function get_option($option, $default = false) {
        return $default;
    }
}

// Include helper funksjoner direkte
require_once 'includes/helpers.php';
require_once 'includes/data-processing.php';

echo "<h2>Direct Badge Function Test</h2>\n";

// Test data som simulerer API response med badges
$test_valp = [
    'KUID' => '2334',
    'kennel' => 'Test Kennel',
    'FatherName' => "Huldreveien's Wild Desert Storm",
    'FatherReg' => 'NO46865/21',
    'MotherName' => 'Test Mother',
    'MotherReg' => 'NO12345/20',
    'avlsh' => '1',    // API flagg: avlshund i kullet
    'eliteh' => '1',   // API flagg: elite i kullet
    'premie' => '13',  // Fars premie score
    'PremieM' => '8',  // Mors premie score
];

// Test data for Black Luckys Philippa
$test_philippa = [
    'KUID' => '1234',
    'kennel' => 'Black Luckys',
    'FatherName' => 'Test Father',
    'FatherReg' => 'NO11111/20',
    'MotherName' => 'Black Luckys Philippa',
    'MotherReg' => 'NO55555/19',
    'avlsh' => '0',    // Ingen avlshund i kullet
    'eliteh' => '1',   // Elite i kullet
    'premie' => '5',   // Fars premie score (lavere)
    'PremieM' => '8',  // Mors premie score (høyere) - Philippa skal få elite
];

echo "<h3>1. Original test data - Wild Desert Storm</h3>\n";
echo "<pre>";
print_r($test_valp);
echo "</pre>";

echo "<h3>2. Test convert_to_individual_structure</h3>\n";
if (function_exists('convert_to_individual_structure')) {
    $processed = convert_to_individual_structure([$test_valp]);
    
    echo "Prosessert data:\n";
    echo "<pre>";
    print_r($processed[0]);
    echo "</pre>";
    
    echo "<h3>3. Test get_dog_status for far</h3>\n";
    if (function_exists('get_dog_status')) {
        $father_status = get_dog_status($processed[0], 'father', true);
        echo "Far status:\n";
        echo "<pre>";
        print_r($father_status);
        echo "</pre>";
        
        echo "<h3>4. Test get_dog_status for mor</h3>\n";
        $mother_status = get_dog_status($processed[0], 'mother', true);
        echo "Mor status:\n";
        echo "<pre>";
        print_r($mother_status);
        echo "</pre>";
        
        echo "<h3>5. Resultater - Wild Desert Storm</h3>\n";
        if ($father_status['elitehund']) {
            echo "✅ Far viser som elitehund: " . $father_status['elitehund_reason'] . "\n";
        } else {
            echo "❌ Far viser IKKE som elitehund\n";
        }
        
        if ($father_status['avlshund']) {
            echo "✅ Far viser som avlshund: " . $father_status['avlshund_reason'] . "\n";
        } else {
            echo "❌ Far viser IKKE som avlshund\n";
        }
        
        if ($mother_status['elitehund']) {
            echo "✅ Mor viser som elitehund: " . $mother_status['elitehund_reason'] . "\n";
        } else {
            echo "❌ Mor viser IKKE som elitehund\n";
        }
        
        echo "<hr>";
        echo "<h3>6. Test Black Luckys Philippa</h3>\n";
        echo "Philippa test data:\n";
        echo "<pre>";
        print_r($test_philippa);
        echo "</pre>";
        
        $processed_philippa = convert_to_individual_structure([$test_philippa]);
        echo "Prosessert Philippa data:\n";
        echo "<pre>";
        print_r($processed_philippa[0]);
        echo "</pre>";
        
        echo "<h3>7. Test Philippa som mor (hun skal være elite)</h3>\n";
        $philippa_mother_status = get_dog_status($processed_philippa[0], 'mother', true);
        echo "Philippa (mor) status:\n";
        echo "<pre>";
        print_r($philippa_mother_status);
        echo "</pre>";
        
        echo "<h3>8. Test Philippa far (han skal IKKE være elite)</h3>\n";
        $philippa_father_status = get_dog_status($processed_philippa[0], 'father', true);
        echo "Philippa far status:\n";
        echo "<pre>";
        print_r($philippa_father_status);
        echo "</pre>";
        
        echo "<h3>9. Philippa Resultater</h3>\n";
        if ($philippa_mother_status['elitehund']) {
            echo "✅ Philippa (mor) viser som elitehund: " . $philippa_mother_status['elitehund_reason'] . "\n";
        } else {
            echo "❌ Philippa (mor) viser IKKE som elitehund\n";
        }
        
        if ($philippa_father_status['elitehund']) {
            echo "❌ Far viser som elitehund (FEIL - han har lavere premie)\n";
        } else {
            echo "✅ Far viser IKKE som elitehund (KORREKT - han har lavere premie)\n";
        }
        
    } else {
        echo "❌ get_dog_status funksjonen ikke funnet\n";
    }
} else {
    echo "❌ convert_to_individual_structure funksjonen ikke funnet\n";
}

?>
