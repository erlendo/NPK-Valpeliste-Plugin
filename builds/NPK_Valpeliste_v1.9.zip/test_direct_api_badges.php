<?php
// Test av DIREKTE API badge-system
require_once __DIR__ . '/includes/data-processing.php';

echo "<h2>Test av direkte API badge-logikk</h2>";

// Test data basert på faktisk API respons
$test_dogs = [
    [
        'id' => '15821',
        'FatherName' => 'Cacciatore',
        'father' => 'VDH/DKK15LBPKTX',
        'MotherName' => 'Quelinda Quercus',
        'mother' => 'DKK01468/2015',
        'avlsh' => '0',
        'eliteh' => '1',  // Kullet HAR elite
        'premie' => '39', // Far har høy premie
        'PremieM' => '31', // Mor har også høy premie
    ],
    [
        'id' => '15823',
        'FatherName' => 'Wild Desert Storm',
        'father' => 'NO UCH VDH/GLP15LBRU9',
        'MotherName' => 'Philippa',
        'mother' => 'VDH/DKK15LB139',
        'avlsh' => '0',
        'eliteh' => '1',  // Kullet HAR elite
        'premie' => '13', // Far har lavere premie
        'PremieM' => '8',  // Mor har enda lavere premie
    ],
    [
        'id' => '15824',
        'FatherName' => 'Test Far',
        'father' => 'TEST123',
        'MotherName' => 'Test Mor',
        'mother' => 'TEST456',
        'avlsh' => '1',  // HAR avlshund
        'eliteh' => '0',  // INGEN elite
        'premie' => '0',
        'PremieM' => '0',
    ]
];

$processed = convert_to_individual_structure($test_dogs);

foreach ($processed as $i => $dog) {
    echo "<h3>Kull " . ($i + 1) . " (ID: " . $dog['id'] . ")</h3>";
    echo "<strong>API data:</strong> avlsh='" . $test_dogs[$i]['avlsh'] . "', eliteh='" . $test_dogs[$i]['eliteh'] . "'<br>";
    
    echo "<strong>Far (" . $dog['father']['name'] . "):</strong><br>";
    echo "- Avlshund: " . ($dog['father']['avlsh'] == '1' ? 'JA ✅' : 'NEI ❌') . "<br>";
    echo "- Elitehund: " . ($dog['father']['eliteh'] == '1' ? 'JA ✅' : 'NEI ❌') . "<br>";
    echo "- Premie: " . (isset($dog['father']['premie']) ? $dog['father']['premie'] : '0') . "<br><br>";
    
    echo "<strong>Mor (" . $dog['mother']['name'] . "):</strong><br>";
    echo "- Avlshund: " . ($dog['mother']['avlsh'] == '1' ? 'JA ✅' : 'NEI ❌') . "<br>";
    echo "- Elitehund: " . ($dog['mother']['eliteh'] == '1' ? 'JA ✅' : 'NEI ❌') . "<br>";
    echo "- Premie: " . (isset($dog['mother']['PremieM']) ? $dog['mother']['PremieM'] : '0') . "<br>";
    
    echo "<hr>";
}

echo "<h3>Forventet resultat:</h3>";
echo "<strong>Kull 1 (Cacciatore):</strong> Far (39 premie) > Mor (31 premie) → Far får eliteh ✅<br>";
echo "<strong>Kull 2 (Wild Desert Storm):</strong> Far (13 premie) > Mor (8 premie) → Far får eliteh ✅<br>";
echo "<strong>Kull 3 (Test):</strong> Har avlsh='1' → Begge får avlshund ✅, Ingen elite<br>";
?>
