<!DOCTYPE html>
<html>
<head>
    <title>NPK Badge Test</title>
    <link rel="stylesheet" type="text/css" href="http://pointerdatabasen.local/wp-content/plugins/NPK_Valpeliste/assets/css/npk-valpeliste.css">
</head>
<body>
    <h1>NPK Badge Test</h1>
    
    <?php
    // Include WordPress
    require_once('/Users/erlendo/Local Sites/pointerdatabasen/app/public/wp-config.php');
    
    // Include plugin files
    require_once('/Users/erlendo/Local Sites/pointerdatabasen/app/public/wp-content/plugins/NPK_Valpeliste/npk_valpeliste.php');
    require_once('/Users/erlendo/Local Sites/pointerdatabasen/app/public/wp-content/plugins/NPK_Valpeliste/live_display_example.php');
    
    // Test the shortcode with debug
    if (function_exists('npk_valpeliste_shortcode')) {
        echo npk_valpeliste_shortcode(['debug' => 'yes']);
    } else {
        echo "Shortcode function not found!";
    }
    ?>
</body>
</html>
