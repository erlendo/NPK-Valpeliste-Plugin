<?php
/**
 * NPK Data Extractor - Modifisert for WordPress Live Display
 * Versjon uten JSON fillagring - returnerer data direkte
 */

class NPKDataExtractorLive {
    private bool $debug;
    private float $rateLimit = 0.5; // Sekunder mellom API-kall
    private $cookieJar;
    private array $sessionCookies = [];
    
    // Liste over godkjente kull KUID-er i henhold til avlskriterier
    private array $approvedLitters = [2340, 2341];

    public function __construct(bool $debug = false) {
        $this->debug = $debug;
        // Use a more persistent cookie file name
        $this->cookieJar = sys_get_temp_dir() . '/npk_cookies_' . date('Ymd') . '.txt';
        
        // Only delete old cookie files (older than today)
        $pattern = sys_get_temp_dir() . '/npk_cookies_*.txt';
        foreach (glob($pattern) as $file) {
            $fileDate = basename($file, '.txt');
            $fileDate = str_replace('npk_cookies_', '', $fileDate);
            if ($fileDate < date('Ymd')) {
                unlink($file);
            }
        }
    }

    public function __destruct() {
        // Don't delete cookie file automatically - let it persist for the day
        // This allows multiple requests to use the same authentication session
    }

    /**
     * Sjekk om et kull er godkjent i henhold til avlskriterier
     */
    public function isLitterApproved(int $kuid): bool {
        return in_array($kuid, $this->approvedLitters);
    }

    /**
     * Autentiser mot NPK API
     */
    public function authenticate(): bool {
        try {
            if ($this->debug) {
                error_log("NPK: Starter autentisering...");
            }

            // Steg 1: Hent login side
            $loginUrl = 'https://pointer.datahound.no/admin';
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $loginUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_COOKIEJAR => $this->cookieJar,
                CURLOPT_COOKIEFILE => $this->cookieJar,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => [
                    'Cache-Control: no-cache',
                    'Pragma: no-cache'
                ]
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                if ($this->debug) error_log("NPK: Login side feil - HTTP $httpCode");
                return false;
            }

            // Steg 2: Send login credentials med korrekte feltnavn
            $authUrl = 'https://pointer.datahound.no/admin/index/auth';
            $postData = 'admin_username=demo&admin_password=demo&login=login';

            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $authUrl,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_COOKIEJAR => $this->cookieJar,
                CURLOPT_COOKIEFILE => $this->cookieJar,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/x-www-form-urlencoded',
                    'Cache-Control: no-cache'
                ]
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $success = ($httpCode === 302); // Redirect = success
            
            if ($this->debug) {
                error_log("NPK: Autentisering " . ($success ? "SUKSESS" : "FEILET") . " - HTTP $httpCode");
            }

            return $success;

        } catch (Exception $e) {
            if ($this->debug) error_log("NPK: Autentisering exception - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Hent valpeliste fra NPK API
     */
    public function getValpeliste(): array {
        try {
            if ($this->debug) {
                error_log("NPK: Henter valpeliste...");
            }

            $url = 'https://pointer.datahound.no/admin/product/getvalpeliste';
            
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_COOKIEFILE => $this->cookieJar,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => [
                    'Cache-Control: no-cache',
                    'Accept: application/json'
                ]
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                if ($this->debug) error_log("NPK: Valpeliste API feil - HTTP $httpCode");
                return ['error' => "HTTP $httpCode"];
            }

            $data = json_decode($response, true);
            if (!$data) {
                if ($this->debug) error_log("NPK: Ugyldig JSON respons");
                return ['error' => 'Ugyldig JSON'];
            }

            if ($this->debug) {
                $count = isset($data['dogs']) ? count($data['dogs']) : 0;
                error_log("NPK: Hentet $count kull fra valpeliste");
            }

            return $data;

        } catch (Exception $e) {
            if ($this->debug) error_log("NPK: Valpeliste exception - " . $e->getMessage());
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Bygg komplett datasett - returner direkte uten fillagring
     */
    public function buildCompleteDataset(): array {
        try {
            $valpeliste = $this->getValpeliste();
            
            if (isset($valpeliste['error'])) {
                return $valpeliste; // Return error
            }

            $dataset = [
                'metadata' => [
                    'ekstraksjonstidspunkt' => date('c'),
                    'antall_kull' => isset($valpeliste['dogs']) ? count($valpeliste['dogs']) : 0,
                    'kilde' => 'NPK API Live'
                ],
                'kull' => [],
                'statistikk' => [
                    'elite_modre' => 0,
                    'elite_fedre' => 0,
                    'avls_modre' => 0,
                    'avls_fedre' => 0,
                    'godkjente_kull' => 0
                ]
            ];

            if (!isset($valpeliste['dogs']) || !is_array($valpeliste['dogs'])) {
                return $dataset;
            }

            foreach ($valpeliste['dogs'] as $litter) {
                // Først definer basiskulldata
                $kullData = [
                    'kull_info' => [
                        'KUID' => $litter['KUID'] ?? '',
                        'opprettet' => $litter['created'] ?? '',
                        'status' => $litter['status'] ?? '',
                        'fodt' => $litter['estDate'] ?? $litter['BirthDate'] ?? '',
                        'godkjent_avlskriterier' => $this->isLitterApproved((int)($litter['KUID'] ?? 0))
                    ],
                    'mor' => [
                        'navn' => $litter['MotherName_REMOVED'] ?? '',
                        'registreringsnummer' => $litter['mother'] ?? '',
                        'elitehund' => false, // Hentes fra individuell API
                        'avlshund' => false,  // Hentes fra individuell API
                        'hdi' => [],
                        'premier' => []
                    ],
                    'far' => [
                        'navn' => $litter['FatherName_REMOVED'] ?? '',
                        'registreringsnummer' => $litter['father'] ?? '',
                        'elitehund' => false, // Hentes fra individuell API
                        'avlshund' => false,  // Hentes fra individuell API
                        'hdi' => [],
                        'premier' => []
                    ],
                    'oppdretter' => [
                        'navn' => $litter['EierNavn'] ?? '',
                        'kennel' => $litter['kennel'] ?? '',
                        'sted' => ($litter['place'] ?? '') . ($litter['zip'] ? ' (' . $litter['zip'] . ')' : ''),
                        'kontakt' => [
                            'telefon' => $litter['phone'] ?? '',
                            'epost' => $litter['email'] ?? ''
                        ]
                    ],
                    'annonse_tekst' => $this->cleanHtml($litter['note'] ?? '')
                ];

                // Så hent individuelle badge data for mor og far
                if (!empty($kullData['mor']['registreringsnummer'])) {
                    $morStatus = $this->getEliteStatus($kullData['mor']['registreringsnummer']);
                    if ($morStatus['status'] === 'SUCCESS') {
                        $kullData['mor']['navn'] = $morStatus['navn'] ?? '';
                        $kullData['mor']['elitehund'] = $morStatus['elitehund'];
                        $kullData['mor']['avlshund'] = $morStatus['avlshund'];
                    }
                    usleep(500000); // Rate limiting - 0.5 seconds
                }

                if (!empty($kullData['far']['registreringsnummer'])) {
                    $farStatus = $this->getEliteStatus($kullData['far']['registreringsnummer']);
                    if ($farStatus['status'] === 'SUCCESS') {
                        $kullData['far']['navn'] = $farStatus['navn'] ?? '';
                        $kullData['far']['elitehund'] = $farStatus['elitehund'];
                        $kullData['far']['avlshund'] = $farStatus['avlshund'];
                    }
                    usleep(500000); // Rate limiting - 0.5 seconds
                }

                // Oppdater statistikk
                if ($kullData['mor']['elitehund']) $dataset['statistikk']['elite_modre']++;
                if ($kullData['mor']['avlshund']) $dataset['statistikk']['avls_modre']++;
                if ($kullData['far']['elitehund']) $dataset['statistikk']['elite_fedre']++;
                if ($kullData['far']['avlshund']) $dataset['statistikk']['avls_fedre']++;
                
                // Godkjent kull hvis minst en forelder har avl/elite
                if ($kullData['mor']['elitehund'] || $kullData['mor']['avlshund'] || 
                    $kullData['far']['elitehund'] || $kullData['far']['avlshund']) {
                    $dataset['statistikk']['godkjente_kull']++;
                }

                $dataset['kull'][] = $kullData;
            }

            if ($this->debug) {
                error_log("NPK: Komplett datasett bygget - " . count($dataset['kull']) . " kull");
            }

            return $dataset;

        } catch (Exception $e) {
            if ($this->debug) error_log("NPK: Dataset exception - " . $e->getMessage());
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Rens HTML og entities fra tekst
     */
    private function cleanHtml(string $text): string {
        if (empty($text)) return '';
        
        // Strip HTML tags
        $cleaned = strip_tags($text);
        
        // Decode HTML entities
        $cleaned = html_entity_decode($cleaned, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // Trim whitespace
        $cleaned = trim($cleaned);
        
        return $cleaned;
    }

    /**
     * Hent elite-status for en hund (nå fungerer!)
     */
    public function getEliteStatus(string $regnr): array {
        try {
            if ($this->debug) {
                error_log("NPK: Henter elite-status for $regnr...");
            }

            $url = "https://pointer.datahound.no/admin/product/getdog?id=" . urlencode($regnr);
            
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_COOKIEFILE => $this->cookieJar,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => [
                    'Accept: application/json',
                    'Cache-Control: no-cache'
                ]
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode !== 200) {
                if ($this->debug) error_log("NPK: Elite-status API feil - HTTP $httpCode for $regnr");
                return [
                    'registreringsnummer' => $regnr,
                    'elitehund' => false,
                    'avlshund' => false,
                    'status' => 'API_ERROR',
                    'note' => "HTTP $httpCode"
                ];
            }

            $data = json_decode($response, true);
            if (!$data || !isset($data['dogs'])) {
                if ($this->debug) error_log("NPK: Ugyldig JSON respons for $regnr");
                return [
                    'registreringsnummer' => $regnr,
                    'elitehund' => false,
                    'avlshund' => false,
                    'status' => 'INVALID_JSON',
                    'note' => 'Kunne ikke parse respons'
                ];
            }

            $dogData = $data['dogs'];
            $eliteStatus = !empty($dogData['eliteh']) && $dogData['eliteh'] == '1';
            $avlsStatus = !empty($dogData['avlsh']) && $dogData['avlsh'] == '1';

            if ($this->debug) {
                error_log("NPK: $regnr - Elite: " . ($eliteStatus ? 'JA' : 'NEI') . ", Avl: " . ($avlsStatus ? 'JA' : 'NEI'));
            }

            return [
                'registreringsnummer' => $regnr,
                'navn' => $dogData['Navn'] ?? '',
                'elitehund' => $eliteStatus,
                'avlshund' => $avlsStatus,
                'premie' => $dogData['premie'] ?? '',
                'premieJakt' => $dogData['premieJakt'] ?? 0,
                'status' => 'SUCCESS',
                'note' => 'Data hentet fra individuell API'
            ];

        } catch (Exception $e) {
            if ($this->debug) error_log("NPK: Elite-status exception for $regnr - " . $e->getMessage());
            return [
                'registreringsnummer' => $regnr,
                'elitehund' => false,
                'avlshund' => false,
                'status' => 'EXCEPTION',
                'note' => $e->getMessage()
            ];
        }
    }
}

?>
