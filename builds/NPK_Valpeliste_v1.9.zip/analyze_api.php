<?php
/**
 * JSON STRUKTUR OG SHORTCODE KONTROLL
 */

require_once 'NPKDataExtractorLive.php';
require_once 'live_display_example.php';

echo "=== JSON STRUKTUR & SHORTCODE ANALYSE ===\n\n";

// 1. Test NPKDataExtractorLive
$extractor = new NPKDataExtractorLive(false);

echo "1. Autentisering...\n";
if (!$extractor->authenticate()) {
    echo "❌ Auth feilet\n";
    exit;
}
echo "✅ Auth OK\n\n";

// 2. Bygg datasett
echo "2. Bygger datasett...\n";
$data = $extractor->buildCompleteDataset();

if (isset($data['error'])) {
    echo "❌ Datasett feil: " . $data['error'] . "\n";
    exit;
}

echo "✅ Datasett OK\n";
echo "Antall kull: " . $data['metadata']['antall_kull'] . "\n\n";

// 3. Analyser JSON struktur
echo "3. JSON STRUKTUR:\n";
echo "metadata.ekstraksjonstidspunkt: " . $data['metadata']['ekstraksjonstidspunkt'] . "\n";
echo "metadata.antall_kull: " . $data['metadata']['antall_kull'] . "\n";
echo "metadata.kilde: " . $data['metadata']['kilde'] . "\n\n";

echo "statistikk.elite_modre: " . $data['statistikk']['elite_modre'] . "\n";
echo "statistikk.elite_fedre: " . $data['statistikk']['elite_fedre'] . "\n";
echo "statistikk.avls_modre: " . $data['statistikk']['avls_modre'] . "\n";
echo "statistikk.avls_fedre: " . $data['statistikk']['avls_fedre'] . "\n\n";

// 4. Første kull detaljer
if (!empty($data['kull'])) {
    $kull1 = $data['kull'][0];
    echo "4. FØRSTE KULL STRUKTUR:\n";
    echo "kull_info.KUID: " . $kull1['kull_info']['KUID'] . "\n";
    echo "oppdretter.kennel: " . $kull1['oppdretter']['kennel'] . "\n";
    echo "mor.navn: " . $kull1['mor']['navn'] . "\n";
    echo "mor.registreringsnummer: " . $kull1['mor']['registreringsnummer'] . "\n";
    echo "mor.elitehund: " . json_encode($kull1['mor']['elitehund']) . "\n";
    echo "mor.avlshund: " . json_encode($kull1['mor']['avlshund']) . "\n";
    echo "far.navn: " . $kull1['far']['navn'] . "\n";
    echo "far.registreringsnummer: " . $kull1['far']['registreringsnummer'] . "\n";
    echo "far.elitehund: " . json_encode($kull1['far']['elitehund']) . "\n";
    echo "far.avlshund: " . json_encode($kull1['far']['avlshund']) . "\n\n";
}

// 5. Test shortcode
echo "5. SHORTCODE TEST:\n";

// Test npk_get_live_data
echo "Testing npk_get_live_data()...\n";
$shortcodeData = npk_get_live_data();
if (isset($shortcodeData['error'])) {
    echo "❌ npk_get_live_data error: " . $shortcodeData['error'] . "\n";
} else {
    echo "✅ npk_get_live_data OK\n";
}

// Test shortcode HTML generation
echo "Testing npk_valpeliste_shortcode()...\n";
$html = npk_valpeliste_shortcode([]);

if (strpos($html, 'npk-error') !== false) {
    echo "❌ Shortcode error detected\n";
    echo "Error content: " . substr($html, 0, 200) . "\n";
} else {
    echo "✅ Shortcode HTML generated\n";
    echo "HTML length: " . strlen($html) . " bytes\n";
    
    // Tell badges
    $eliteCount = substr_count($html, 'badge elite');
    $avlCount = substr_count($html, 'badge avl');
    $noBadgeCount = substr_count($html, 'Ingen spesielle merknader');
    
    echo "Elite badges i HTML: $eliteCount\n";
    echo "Avl badges i HTML: $avlCount\n";
    echo "'Ingen badges' meldinger: $noBadgeCount\n";
    
    if ($eliteCount > 0 || $avlCount > 0) {
        echo "🏆 BADGES VISES I SHORTCODE!\n";
    } else {
        echo "⚠️ Ingen badges funnet i shortcode HTML\n";
    }
}

echo "\n6. SAMMENLIGNING JSON vs SHORTCODE:\n";
echo "JSON elite_modre: " . $data['statistikk']['elite_modre'] . "\n";
echo "HTML elite badges: " . ($eliteCount ?? 0) . "\n";
echo "JSON avls_modre: " . $data['statistikk']['avls_modre'] . "\n";
echo "HTML avl badges: " . ($avlCount ?? 0) . "\n";

echo "\n=== ANALYSE FULLFØRT ===\n";
?>