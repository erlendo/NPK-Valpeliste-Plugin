<?php
/**
 * Search for Rypeparadiset's Cacciatore (NO58331/21)
 */

echo "=== Searching for Rypeparadiset's Cacciatore (NO58331/21) ===\n\n";

$login_url = 'https://pointer.datahound.no/admin';
$login_action_url = 'https://pointer.datahound.no/admin/index/auth';
$username = 'demo';
$password = 'demo';

// Initialize cURL
$ch = curl_init();

// Get login page first
curl_setopt_array($ch, [
    CURLOPT_URL => $login_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => '/tmp/cookies.txt',
    CURLOPT_COOKIEFILE => '/tmp/cookies.txt',
    CURLOPT_USERAGENT => 'NPK Valpeliste Test',
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_VERBOSE => false
]);

$login_page = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($http_code == 200) {
    // Look for CSRF token
    $csrf_token = '';
    if (preg_match('/<input[^>]*name=["\']_token["\'][^>]*value=["\']([^"\']*)["\']/', $login_page, $matches)) {
        $csrf_token = $matches[1];
    }

    // Prepare login data
    $login_data = http_build_query([
        'admin_username' => $username,
        'admin_password' => $password,
        'login' => 'login',
        '_token' => $csrf_token,
        'csrf_token' => $csrf_token
    ]);

    // Perform login
    curl_setopt_array($ch, [
        CURLOPT_URL => $login_action_url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $login_data,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
            'Referer: ' . $login_url,
            'Origin: https://pointer.datahound.no'
        ]
    ]);

    $login_response = curl_exec($ch);
    $login_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Check if login was successful
    $login_successful = false;
    if ($login_http_code == 302 || $login_http_code == 301) {
        $login_successful = true;
    } elseif (strpos($login_response, 'dashboard') !== false || 
              strpos($login_response, 'admin') !== false ||
              strpos($login_response, 'logout') !== false) {
        $login_successful = true;
    }

    if ($login_successful) {
        echo "✅ Authentication successful\n\n";
        
        // Get API data
        curl_setopt_array($ch, [
            CURLOPT_URL => 'https://pointer.datahound.no/admin/product/getvalpeliste',
            CURLOPT_POST => false,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Referer: https://pointer.datahound.no/admin/'
            ]
        ]);
        
        $api_response = curl_exec($ch);
        $api_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($api_http_code == 200) {
            $data = json_decode($api_response, true);
            
            if ($data && isset($data['dogs'])) {
                echo "Found " . count($data['dogs']) . " dogs in system\n\n";
                
                $found = false;
                
                // Search for Rypeparadiset's Cacciatore
                foreach ($data['dogs'] as $index => $dog) {
                    $search_fields = ['FatherName', 'MotherName', 'father', 'mother'];
                    $search_terms = ['Rypeparadiset', 'Cacciatore', 'NO58331/21'];
                    
                    $dog_found = false;
                    foreach ($search_fields as $field) {
                        if (isset($dog[$field])) {
                            foreach ($search_terms as $term) {
                                if (stripos($dog[$field], $term) !== false) {
                                    $dog_found = true;
                                    break 2;
                                }
                            }
                        }
                    }
                    
                    if ($dog_found) {
                        echo "=== FOUND Rypeparadiset's Cacciatore in Dog {$index} ===\n";
                        echo "KUID: " . ($dog['KUID'] ?? 'N/A') . "\n";
                        echo "Kennel: " . ($dog['kennel'] ?? 'N/A') . "\n";
                        echo "Father: " . ($dog['FatherName'] ?? 'N/A') . "\n";
                        echo "Father Reg: " . ($dog['father'] ?? 'N/A') . "\n";
                        echo "Mother: " . ($dog['MotherName'] ?? 'N/A') . "\n";
                        echo "Mother Reg: " . ($dog['mother'] ?? 'N/A') . "\n";
                        echo "\n";
                        
                        // Badge information
                        echo "BADGE INFORMATION:\n";
                        echo "avlsh (breeding dog): '" . ($dog['avlsh'] ?? '') . "'\n";
                        echo "eliteh (elite dog): '" . ($dog['eliteh'] ?? '') . "'\n";
                        echo "premie: '" . ($dog['premie'] ?? '') . "'\n";
                        echo "jakt: '" . ($dog['jakt'] ?? '') . "'\n";
                        echo "PremieM: '" . ($dog['PremieM'] ?? '') . "'\n";
                        echo "jaktM: '" . ($dog['jaktM'] ?? '') . "'\n";
                        echo "\n";
                        
                        // Ribbon information
                        echo "RIBBON INFORMATION:\n";
                        echo "FatherPrem: " . ($dog['FatherPrem'] ?? 'N/A') . "\n";
                        echo "MotherPrem: " . ($dog['MotherPrem'] ?? 'N/A') . "\n";
                        echo "\n";
                        
                        // Show which field matched
                        foreach ($search_fields as $field) {
                            if (isset($dog[$field])) {
                                foreach ($search_terms as $term) {
                                    if (stripos($dog[$field], $term) !== false) {
                                        echo "*** FOUND '{$term}' in field '{$field}': '{$dog[$field]}'\n";
                                    }
                                }
                            }
                        }
                        
                        $found = true;
                        echo "\n";
                    }
                }
                
                if (!$found) {
                    echo "❌ Rypeparadiset's Cacciatore (NO58331/21) NOT found in current data\n\n";
                    echo "Current dogs in system:\n";
                    foreach ($data['dogs'] as $index => $dog) {
                        echo "Dog {$index}: " . ($dog['kennel'] ?? 'N/A') . "\n";
                        echo "  Father: " . ($dog['FatherName'] ?? 'N/A') . " (" . ($dog['father'] ?? 'N/A') . ")\n";
                        echo "  Mother: " . ($dog['MotherName'] ?? 'N/A') . " (" . ($dog['mother'] ?? 'N/A') . ")\n";
                        echo "\n";
                    }
                } else {
                    echo "=== SUMMARY ===\n";
                    echo "✅ Rypeparadiset's Cacciatore found in current active litter data\n";
                }
                
            } else {
                echo "❌ No dogs data in API response\n";
            }
        } else {
            echo "❌ API call failed with status: {$api_http_code}\n";
        }
    } else {
        echo "❌ Authentication failed\n";
    }
} else {
    echo "❌ Login page access failed\n";
}

curl_close($ch);
echo "\n=== Search Complete ===\n";
?>
