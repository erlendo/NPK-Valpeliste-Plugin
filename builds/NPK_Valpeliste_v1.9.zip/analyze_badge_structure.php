<?php
echo "=== Detaljert Badge Struktur Analyse ===\n\n";

// Last inn cached API data
$json_data = file_get_contents('api_response.json');
$data = json_decode($json_data, true);

if (!$data || !isset($data['dogs'])) {
    echo "Kunne ikke laste API data\n";
    exit;
}

echo "Antall kull i cached data: " . $data['totalCount'] . "\n\n";

foreach ($data['dogs'] as $index => $litter) {
    echo "=== KULL " . ($index + 1) . " ===\n";
    echo "KUID: " . $litter['KUID'] . "\n";
    echo "Kennel: " . $litter['kennel'] . "\n";
    echo "Far: " . $litter['FatherName'] . "\n";
    echo "Mor: " . $litter['MotherName'] . "\n";
    
    // Søk etter alle badge-relaterte felter
    $badge_fields = [];
    foreach ($litter as $key => $value) {
        if (preg_match('/avl|elite|badge|ribbon|prem/i', $key) || 
            (is_string($value) && preg_match('/avl|elite|badge|ribbon/i', $value))) {
            $badge_fields[$key] = $value;
        }
    }
    
    echo "\nBadge-relaterte felter:\n";
    foreach ($badge_fields as $field => $value) {
        if (is_string($value) && strlen($value) > 100) {
            $value = substr($value, 0, 100) . "...";
        }
        echo "  $field: " . json_encode($value) . "\n";
    }
    
    echo "\n" . str_repeat("-", 50) . "\n\n";
}

// Søk også etter potensielle individuelle badge felter i alle data
echo "\n=== SØKER ETTER INDIVIDUELLE BADGE PATTERNS ===\n";
$all_keys = [];
foreach ($data['dogs'] as $litter) {
    foreach ($litter as $key => $value) {
        $all_keys[] = $key;
    }
}

$unique_keys = array_unique($all_keys);
$potential_individual_fields = [];

foreach ($unique_keys as $key) {
    if (preg_match('/(ind|Individual|Dog|Puppy|Valp|F|M|Father|Mother).*[Aa]vl/i', $key) ||
        preg_match('/(ind|Individual|Dog|Puppy|Valp|F|M|Father|Mother).*[Ee]lite/i', $key) ||
        preg_match('/[Aa]vl.*(ind|Individual|Dog|Puppy|Valp|F|M)/i', $key) ||
        preg_match('/[Ee]lite.*(ind|Individual|Dog|Puppy|Valp|F|M)/i', $key)) {
        $potential_individual_fields[] = $key;
    }
}

if (!empty($potential_individual_fields)) {
    echo "Potensielle individuelle badge felter funnet:\n";
    foreach ($potential_individual_fields as $field) {
        echo "  - $field\n";
    }
} else {
    echo "Ingen individuelle badge felter funnet i API strukturen.\n";
}

echo "\n=== KONKLUSJON ===\n";
echo "Badges finnes kun på kull-nivå (avlsh, eliteh) - ikke på individ-nivå.\n";
echo "Dette betyr at API-en ikke inneholder individuelle badge flagg.\n";
?>
