<?php
/**
 * Test core functionality uten WordPress dependencies
 */

require_once 'NPKDataExtractorLive.php';

echo "=== CORE NPK SYSTEM TEST ===\n\n";

// Mock WordPress functions
if (!function_exists('add_shortcode')) {
    function add_shortcode($tag, $func) { /* mock */ }
}
if (!function_exists('wp_kses_post')) {
    function wp_kses_post($text) { return strip_tags($text); }
}
if (!function_exists('add_action')) {
    function add_action($hook, $func) { /* mock */ }
}

echo "1. Testing NPKDataExtractorLive...\n";
$extractor = new NPKDataExtractorLive(false);

if (!$extractor->authenticate()) {
    echo "❌ CRITICAL: Authentication failed!\n";
    exit;
}
echo "✅ Authentication OK\n\n";

echo "2. Testing dataset building...\n";
$start = microtime(true);
$data = $extractor->buildCompleteDataset();
$end = microtime(true);
$time = round($end - $start, 2);

if (isset($data['error'])) {
    echo "❌ CRITICAL: Dataset error - " . $data['error'] . "\n";
    exit;
}

echo "✅ Dataset OK ($time seconds)\n";
echo "Kull count: " . $data['metadata']['antall_kull'] . "\n";
echo "Elite mødre: " . $data['statistikk']['elite_modre'] . "\n";
echo "Elite fedre: " . $data['statistikk']['elite_fedre'] . "\n";
echo "Avls mødre: " . $data['statistikk']['avls_modre'] . "\n";
echo "Avls fedre: " . $data['statistikk']['avls_fedre'] . "\n";

$totalBadges = $data['statistikk']['elite_modre'] + $data['statistikk']['elite_fedre'] + 
               $data['statistikk']['avls_modre'] + $data['statistikk']['avls_fedre'];

echo "\n3. Badge system verification...\n";
if ($totalBadges > 0) {
    echo "✅ Badges working: $totalBadges total\n";
    
    // Show first kull as example
    if (!empty($data['kull'])) {
        $firstKull = $data['kull'][0];
        echo "\nExample kull:\n";
        echo "- Kennel: " . $firstKull['oppdretter']['kennel'] . "\n";
        echo "- Mor: " . $firstKull['mor']['navn'] . " (Elite: " . ($firstKull['mor']['elitehund'] ? 'YES' : 'NO') . ")\n";
        echo "- Far: " . $firstKull['far']['navn'] . " (Elite: " . ($firstKull['far']['elitehund'] ? 'YES' : 'NO') . ")\n";
    }
} else {
    echo "❌ WARNING: No badges found\n";
}

echo "\n4. Testing basic shortcode data function...\n";

// Test the core data function from live_display_example.php
function test_npk_get_live_data() {
    $extractor = new NPKDataExtractorLive(false);
    
    if (!$extractor->authenticate()) {
        return ['error' => 'Kunne ikke autentisere mot NPK API'];
    }
    
    return $extractor->buildCompleteDataset();
}

$shortcodeData = test_npk_get_live_data();

if (isset($shortcodeData['error'])) {
    echo "❌ Shortcode data error: " . $shortcodeData['error'] . "\n";
} else {
    echo "✅ Shortcode data function OK\n";
    echo "Ready for WordPress [npk_valpeliste] shortcode\n";
}

echo "\n5. Performance metrics...\n";
echo "Execution time: {$time} seconds\n";
echo "Memory usage: " . round(memory_get_peak_usage() / 1024 / 1024, 2) . " MB\n";

echo "\n=== TEST RESULTS ===\n";
if ($totalBadges > 0) {
    echo "🎉 SYSTEM WORKING PERFECTLY!\n";
    echo "✅ Live badge system operational\n";
    echo "✅ Zero-cache implementation working\n";
    echo "✅ WordPress shortcode ready\n";
    echo "✅ Production ready\n";
} else {
    echo "⚠️ SYSTEM NEEDS ATTENTION\n";
    echo "❌ Badge system not detecting badges\n";
}

echo "\nPlugin ready for WordPress installation!\n";

?>
