<?php
/**
 * Complete test of NPK Valpeliste processing chain
 */

// Mock WordPress functions
if (!function_exists('wp_remote_get')) {
    function wp_remote_get($url, $args = array()) {
        return array('body' => '', 'response' => array('code' => 200));
    }
}

if (!function_exists('wp_remote_post')) {
    function wp_remote_post($url, $args = array()) {
        return array('body' => '', 'response' => array('code' => 200));
    }
}

if (!function_exists('wp_remote_retrieve_body')) {
    function wp_remote_retrieve_body($response) {
        return $response['body'];
    }
}

if (!function_exists('wp_remote_retrieve_response_code')) {
    function wp_remote_retrieve_response_code($response) {
        return $response['response']['code'];
    }
}

if (!function_exists('wp_remote_retrieve_cookies')) {
    function wp_remote_retrieve_cookies($response) {
        return array();
    }
}

if (!function_exists('is_wp_error')) {
    function is_wp_error($thing) {
        return false;
    }
}

// Simple includes to test core logic
require_once 'includes/helpers.php';

echo "=== NPK Valpeliste Complete Processing Test ===\n\n";

// Test data representing Black Luckys Philippa scenario
$api_dog_data = array(
    'KUID' => '2345',
    'kennel' => 'Huldreveien\'s',
    'MotherName' => 'Black Luckys Philippa',
    'avlsh' => '0',
    'eliteh' => '1',
    'vplcolor' => '99CCFF',
    'vpltooltip' => 'Godkjent iht. avlskriterier'
);

echo "=== Step 1: Raw API Data ===\n";
print_r($api_dog_data);

// Simulate convert_to_individual_structure processing
$father = array();
$mother = array();
$valp = $api_dog_data;

foreach ($api_dog_data as $key => $value) {
    if ($key == 'avlsh' || $key == 'eliteh') {
        $mother[$key] = $value;
        continue;
    }
    
    if (preg_match('/^(Mother|mother)/', $key)) {
        $mother[$key] = $value;
        unset($valp[$key]);
    }
}

$valp['father'] = $father;
$valp['mother'] = $mother;

echo "\n=== Step 2: After Data Processing ===\n";
echo "Mother object:\n";
print_r($mother);

// Test badge detection
$mother_status = get_dog_status($mother, 'mother', true);

echo "\n=== Step 3: Badge Detection Results ===\n";
echo "Black Luckys Philippa Status:\n";
echo "- Avlshund: " . ($mother_status['avlshund'] ? 'JA ✅' : 'NEI ❌') . "\n";
echo "- Elitehund: " . ($mother_status['elitehund'] ? 'JA ✅' : 'NEI ❌') . "\n";
echo "- Avlshund reason: " . $mother_status['avlshund_reason'] . "\n";
echo "- Elitehund reason: " . $mother_status['elitehund_reason'] . "\n";

if (isset($mother_status['debug_info'])) {
    echo "\nDebug info:\n";
    print_r($mother_status['debug_info']);
}

// Simulate badge HTML generation
$mother_badges = '';
if ($mother_status['avlshund']) {
    $mother_badges .= '<span class="valpeliste-badge avlshund">Avlshund</span>';
}
if ($mother_status['elitehund']) {
    $mother_badges .= '<span class="valpeliste-badge elitehund">Elitehund</span>';
}

echo "\n=== Step 4: HTML Badge Output ===\n";
echo "Generated badges for Black Luckys Philippa:\n";
echo $mother_badges ? $mother_badges : "Ingen badges";
echo "\n";

echo "\n=== Conclusion ===\n";
if ($mother_status['elitehund']) {
    echo "✅ SUCCESS: Black Luckys Philippa SKAL vise Elitehund-badge\n";
    echo "   Plugin-en fungerer korrekt!\n";
} else {
    echo "❌ PROBLEM: Badge blir ikke detektert\n";
}

echo "\n=== Test Complete ===\n";
