<?php
/**
 * Debug individual API response structure
 */

echo "=== DEBUG INDIVIDUAL API RESPONSE ===\n\n";

require_once 'NPKDataExtractorLive.php';

$extractor = new NPKDataExtractorLive(true); // Enable debug

if (!$extractor->authenticate()) {
    echo "❌ Auth failed\n";
    exit;
}

echo "✅ Auth OK\n\n";

// Test med kjent registreringsnummer
$testDogs = ['NO34007/19', 'NO36477/22'];

foreach ($testDogs as $regnr) {
    echo "--- Testing $regnr ---\n";
    
    // Raw API test
    $url = "https://pointer.datahound.no/admin/product/getdog?id=" . urlencode($regnr);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEFILE => '/tmp/npk_session_live.txt',
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Cache-Control: no-cache'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP Code: $httpCode\n";
    echo "Response length: " . strlen($response) . "\n";
    
    if ($httpCode == 200) {
        $data = json_decode($response, true);
        if ($data) {
            echo "JSON Structure:\n";
            echo "Root keys: " . implode(', ', array_keys($data)) . "\n";
            
            // Check if 'dogs' key exists
            if (isset($data['dogs'])) {
                echo "Found 'dogs' key - Type: " . gettype($data['dogs']) . "\n";
                if (is_array($data['dogs'])) {
                    echo "Dogs array keys: " . implode(', ', array_keys($data['dogs'])) . "\n";
                    echo "eliteh: " . (isset($data['dogs']['eliteh']) ? $data['dogs']['eliteh'] : 'not set') . "\n";
                    echo "avlsh: " . (isset($data['dogs']['avlsh']) ? $data['dogs']['avlsh'] : 'not set') . "\n";
                }
            } else {
                echo "No 'dogs' key found\n";
                // Check for direct fields
                echo "Direct eliteh: " . (isset($data['eliteh']) ? $data['eliteh'] : 'not set') . "\n";
                echo "Direct avlsh: " . (isset($data['avlsh']) ? $data['avlsh'] : 'not set') . "\n";
                echo "Direct premie: " . (isset($data['premie']) ? $data['premie'] : 'not set') . "\n";
            }
            
            echo "Full JSON (first 500 chars):\n";
            echo substr(json_encode($data, JSON_PRETTY_PRINT), 0, 500) . "\n";
            
        } else {
            echo "Invalid JSON\n";
            echo "Raw response (first 300 chars):\n";
            echo substr($response, 0, 300) . "\n";
        }
    } else {
        echo "HTTP Error $httpCode\n";
        echo "Response: " . substr($response, 0, 200) . "\n";
    }
    
    echo "\n";
    
    // Test via extractor method
    echo "Via getEliteStatus method:\n";
    $result = $extractor->getEliteStatus($regnr);
    echo "Status: " . $result['status'] . "\n";
    echo "Elite: " . ($result['elitehund'] ? 'true' : 'false') . "\n";
    echo "Avl: " . ($result['avlshund'] ? 'true' : 'false') . "\n";
    echo "Note: " . ($result['note'] ?? '') . "\n";
    
    echo "\n=================\n\n";
}

?>
