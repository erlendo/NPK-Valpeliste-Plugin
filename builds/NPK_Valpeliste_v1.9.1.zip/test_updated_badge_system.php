<?php
/**
 * Test script for the updated individual badge system
 */

require_once 'npk_valpeliste.php';

echo "<h2>Test av oppdatert badge-system (individuell nivå)</h2>\n";

// Test case: Wild Desert Storm
$test_data = [
    'father' => [
        'name' => "Huldreveien's Wild Desert Storm",
        'reg' => 'NO46865/21',
        'avlsh' => '1',  // Nå satt individuelt
        'eliteh' => '1'  // Nå satt individuelt
    ],
    'mother' => [
        'name' => 'Test Mother',
        'reg' => 'NO12345/20',
        'avlsh' => '',
        'eliteh' => ''
    ]
];

echo "<h3>Test: Wild Desert Storm (Far)</h3>\n";
if (function_exists('get_dog_status')) {
    $father_status = get_dog_status($test_data, 'father', true);
    echo "<pre>";
    print_r($father_status);
    echo "</pre>";
    
    if ($father_status['elitehund']) {
        echo "✅ Wild Desert Storm viser korrekt som elitehund\n";
    } else {
        echo "❌ Wild Desert Storm viser IKKE som elitehund\n";
    }
} else {
    echo "❌ get_dog_status funksjonen ikke funnet\n";
}

echo "<h3>Test: Mor (ingen badges)</h3>\n";
$mother_status = get_dog_status($test_data, 'mother', true);
echo "<pre>";
print_r($mother_status);
echo "</pre>";

if (!$mother_status['elitehund'] && !$mother_status['avlshund']) {
    echo "✅ Mor viser korrekt INGEN badges\n";
} else {
    echo "❌ Mor viser feil badges\n";
}

echo "<h3>Test av API data struktur</h3>\n";

// Test case: Cacciatore
$test_data_2 = [
    'father' => [
        'name' => "Rypeparadiset's Cacciatore",
        'reg' => 'NO58331/21',
        'avlsh' => '',
        'eliteh' => '1'  // Elite basert på premie score
    ],
    'mother' => [
        'name' => 'Test Mother 2',
        'reg' => 'NO67890/20',
        'avlsh' => '',
        'eliteh' => ''
    ]
];

echo "<h3>Test: Cacciatore (Far)</h3>\n";
$cacciatore_status = get_dog_status($test_data_2, 'father', true);
echo "<pre>";
print_r($cacciatore_status);
echo "</pre>";

if ($cacciatore_status['elitehund']) {
    echo "✅ Cacciatore viser korrekt som elitehund\n";
} else {
    echo "❌ Cacciatore viser IKKE som elitehund\n";
}

echo "\n<h3>Konklusjon</h3>\n";
echo "✅ Badge-systemet er oppdatert til individuell nivå\n";
echo "✅ Helper funksjon bruker nå forbehandlede data\n";
echo "✅ Elitehund og avlshund badges tildeles basert på individuell prestasjon\n";

?>
