<?php
require_once 'includes/data-processing.php';

echo "=== Searching for Wild Desert Storm ===\n";

$data = fetch_valpeliste_data();

if ($data && isset($data['dogs'])) {
    echo "Total dogs found: " . count($data['dogs']) . "\n\n";
    
    $found = false;
    
    foreach ($data['dogs'] as $index => $dog) {
        // Search in various fields for Wild Desert Storm or NO46865/21
        $searchTerms = ['Wild Desert Storm', 'NO46865/21'];
        $searchFields = ['FatherName', 'MotherName', 'FatherReg', 'MotherReg'];
        
        foreach ($searchTerms as $term) {
            foreach ($searchFields as $field) {
                if (isset($dog[$field]) && stripos($dog[$field], $term) !== false) {
                    echo "=== FOUND '{$term}' in {$field} ===\n";
                    echo "Dog index: {$index}\n";
                    echo "KUID: " . ($dog['KUID'] ?? 'N/A') . "\n";
                    echo "Kennel: " . ($dog['kennel'] ?? 'N/A') . "\n";
                    echo "{$field}: " . ($dog[$field] ?? 'N/A') . "\n";
                    
                    // Show all relevant badge fields
                    if (strpos($field, 'Father') !== false) {
                        echo "Father Registration: " . ($dog['FatherReg'] ?? 'N/A') . "\n";
                        echo "Father avlsh: " . ($dog['Fatheravlsh'] ?? 'N/A') . "\n";
                        echo "Father eliteh: " . ($dog['Fathereliteh'] ?? 'N/A') . "\n";
                        echo "Father data: " . json_encode([
                            'avlsh' => $dog['Fatheravlsh'] ?? null,
                            'eliteh' => $dog['Fathereliteh'] ?? null
                        ]) . "\n";
                    } else {
                        echo "Mother Registration: " . ($dog['MotherReg'] ?? 'N/A') . "\n";
                        echo "Mother avlsh: " . ($dog['Motheravlsh'] ?? 'N/A') . "\n";
                        echo "Mother eliteh: " . ($dog['Mothereliteh'] ?? 'N/A') . "\n";
                        echo "Mother data: " . json_encode([
                            'avlsh' => $dog['Motheravlsh'] ?? null,
                            'eliteh' => $dog['Mothereliteh'] ?? null
                        ]) . "\n";
                    }
                    
                    echo "\n";
                    $found = true;
                }
            }
        }
    }
    
    if (!$found) {
        echo "Wild Desert Storm (NO46865/21) not found in current data.\n";
        echo "Let me show all available dogs to help identify the issue:\n\n";
        
        foreach ($data['dogs'] as $index => $dog) {
            echo "Dog {$index}:\n";
            echo "  KUID: " . ($dog['KUID'] ?? 'N/A') . "\n";
            echo "  Kennel: " . ($dog['kennel'] ?? 'N/A') . "\n";
            echo "  Father: " . ($dog['FatherName'] ?? 'N/A') . " (" . ($dog['FatherReg'] ?? 'N/A') . ")\n";
            echo "  Mother: " . ($dog['MotherName'] ?? 'N/A') . " (" . ($dog['MotherReg'] ?? 'N/A') . ")\n";
            
            // Check if any parent has eliteh badge
            $father_eliteh = $dog['Fathereliteh'] ?? '';
            $mother_eliteh = $dog['Mothereliteh'] ?? '';
            if (!empty($father_eliteh) || !empty($mother_eliteh)) {
                echo "  ** Has eliteh badges: Father='{$father_eliteh}', Mother='{$mother_eliteh}'\n";
            }
            
            echo "\n";
        }
    }
} else {
    echo "No data available or error fetching data.\n";
    echo "Debug info:\n";
    var_dump($data);
}

echo "=== Search Complete ===\n";
?>
