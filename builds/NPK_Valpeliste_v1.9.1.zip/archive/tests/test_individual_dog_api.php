<?php
/**
 * Test individual dog API endpoint for badge data
 */

echo "=== Test av Individuell Hund API for Badge Data ===\n\n";

$login_url = 'https://pointer.datahound.no/admin';
$login_action_url = 'https://pointer.datahound.no/admin/index/auth';
$username = 'demo';
$password = 'demo';

// Initialize cURL
$ch = curl_init();

// Authentication (simplified)
curl_setopt_array($ch, [
    CURLOPT_URL => $login_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => '/tmp/cookies.txt',
    CURLOPT_COOKIEFILE => '/tmp/cookies.txt',
    CURLOPT_USERAGENT => 'NPK Valpeliste Test',
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
]);

$login_page = curl_exec($ch);
$csrf_token = '';
if (preg_match('/<input[^>]*name=["\']_token["\'][^>]*value=["\']([^"\']*)["\']/', $login_page, $matches)) {
    $csrf_token = $matches[1];
}

curl_setopt_array($ch, [
    CURLOPT_URL => $login_action_url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'admin_username' => $username,
        'admin_password' => $password,
        'login' => 'login',
        '_token' => $csrf_token,
        'csrf_token' => $csrf_token
    ]),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/x-www-form-urlencoded',
        'Referer: ' . $login_url,
        'Origin: https://pointer.datahound.no'
    ]
]);

$login_response = curl_exec($ch);
echo "✅ Autentisering fullført\n\n";

// Test individual dog endpoints
$test_dogs = [
    'Wild Desert Storm' => 'NO46865/21',
    'Black Luckys Philippa' => 'SE16360/2019',
    'Rypeparadiset\'s Cacciatore' => 'NO58331/21'
];

foreach ($test_dogs as $dog_name => $reg_number) {
    echo "=== {$dog_name} ({$reg_number}) ===\n";
    
    $api_url = "https://pointer.datahound.no/admin/product/getdog?reg={$reg_number}";
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url,
        CURLOPT_POST => false,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Referer: https://pointer.datahound.no/admin/'
        ]
    ]);
    
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    echo "API Status: HTTP {$status}\n";
    
    if ($status == 200) {
        echo "Raw response: " . $response . "\n";
        $data = json_decode($response, true);
        
        echo "JSON decode result: " . json_encode($data) . "\n";
        
        if ($data && isset($data['dogs'])) {
            echo "Dogs data: " . json_encode($data['dogs']) . "\n";
        } else {
            echo "❌ Ingen 'dogs' nøkkel eller ugyldig JSON\n";
        }
    } else {
        echo "❌ API kall feilet\n";
    }
    
    echo "\n";
}

curl_close($ch);
echo "=== Test Fullført ===\n";
?>
