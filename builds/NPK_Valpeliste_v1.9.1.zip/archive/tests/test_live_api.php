<?php
/**
 * Test API data structure
 */

// Include functions directly
require_once 'includes/data-processing.php';

echo "<h2>Test av ekte API data</h2>\n";

// Bruk samme logikk som i original kode
$username = 'demo';
$password = 'demo';

// Initialize cURL session for login
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, 'https://pointer.datahound.no/admin');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_COOKIEJAR, '/tmp/cookies.txt');
curl_setopt($curl, CURLOPT_COOKIEFILE, '/tmp/cookies.txt');
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; NPK Valpeliste)');

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

if ($http_code == 200) {
    echo "✅ Tilkobling til login side vellykket\n";
    
    // Extract any necessary form tokens or session info
    // For now, proceed with login
    
    // Perform login
    $post_data = [
        'admin_username' => $username,
        'admin_password' => $password,
        'login' => 'login'
    ];
    
    curl_setopt($curl, CURLOPT_URL, 'https://pointer.datahound.no/admin/index/auth');
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post_data));
    
    $login_response = curl_exec($curl);
    $login_http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    
    if ($login_http_code == 200) {
        echo "✅ Login vellykket\n";
        
        // Now get the valpeliste data
        curl_setopt($curl, CURLOPT_URL, 'https://pointer.datahound.no/admin/product/getvalpeliste');
        curl_setopt($curl, CURLOPT_POST, false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, '');
        
        $api_response = curl_exec($curl);
        $api_http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        if ($api_http_code == 200) {
            echo "✅ API data hentet\n";
            
            $data = json_decode($api_response, true);
            
            if ($data && isset($data['dogs'])) {
                echo "✅ JSON dekoding vellykket - " . count($data['dogs']) . " kull funnet\n\n";
                
                echo "<h3>Første kull (komplett data):</h3>\n";
                echo "<pre>";
                print_r($data['dogs'][0]);
                echo "</pre>";
                
                echo "<h3>Badge-relevante felt i første 3 kull:</h3>\n";
                for ($i = 0; $i < min(3, count($data['dogs'])); $i++) {
                    $dog = $data['dogs'][$i];
                    echo "<h4>Kull " . ($i + 1) . ":</h4>\n";
                    echo "Kennel: " . (isset($dog['kennel']) ? $dog['kennel'] : 'N/A') . "\n";
                    echo "FatherName: " . (isset($dog['FatherName']) ? $dog['FatherName'] : 'N/A') . "\n";
                    echo "MotherName: " . (isset($dog['MotherName']) ? $dog['MotherName'] : 'N/A') . "\n";
                    echo "avlsh: " . (isset($dog['avlsh']) ? $dog['avlsh'] : 'ikke satt') . "\n";
                    echo "eliteh: " . (isset($dog['eliteh']) ? $dog['eliteh'] : 'ikke satt') . "\n";
                    echo "premie: " . (isset($dog['premie']) ? $dog['premie'] : 'ikke satt') . "\n";
                    echo "PremieM: " . (isset($dog['PremieM']) ? $dog['PremieM'] : 'ikke satt') . "\n";
                    
                    // Sjekk for andre badge-relaterte felt
                    $badge_fields = ['avlshF', 'avlshM', 'elitehF', 'elitehM', 'jaktindF', 'jaktindM', 'althdF', 'althdM'];
                    foreach ($badge_fields as $field) {
                        if (isset($dog[$field])) {
                            echo "$field: " . $dog[$field] . "\n";
                        }
                    }
                    echo "\n";
                }
                
                echo "<h3>Alle tilgjengelige felt (fra første kull):</h3>\n";
                echo "<pre>";
                echo implode("\n", array_keys($data['dogs'][0]));
                echo "</pre>";
                
            } else {
                echo "❌ JSON dekoding feilet eller ingen dogs array\n";
                echo "Raw response: " . substr($api_response, 0, 500) . "\n";
            }
            
        } else {
            echo "❌ API kall feilet med HTTP code: $api_http_code\n";
        }
        
    } else {
        echo "❌ Login feilet med HTTP code: $login_http_code\n";
    }
    
} else {
    echo "❌ Tilkobling feilet med HTTP code: $http_code\n";
}

curl_close($curl);

?>
