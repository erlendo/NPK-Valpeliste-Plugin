<?php
/**
 * OPPDATERING: Individuell API funker med korrekte login felter!
 * 
 * RESULTAT fra NO36477/22:
 * - avlsh: (tom)
 * - eliteh: (tom) 
 * - Navn: Goppollens Saga
 * - HD: A
 * - Premie: (tom)
 * 
 * KONKLUSJON: API-en returnerer data, men denne hunden har ingen elite/avl status
 */

require_once 'NPKDataExtractorLive.php';

function testWorkingIndividualAPI() {
    echo "=== OPPDATERT: Individuell API Test ===\n\n";
    
    // Test med korrekte login felter
    $cookieJar = tempnam(sys_get_temp_dir(), 'working_test');
    
    // Login
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://pointer.datahound.no/admin',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_COOKIEJAR => $cookieJar,
        CURLOPT_COOKIEFILE => $cookieJar,
        CURLOPT_USERAGENT => 'Mozilla/5.0',
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    curl_exec($ch);
    curl_close($ch);
    
    // Auth med korrekte feltnavn
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://pointer.datahound.no/admin/index/auth',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => 'admin_username=demo&admin_password=demo&login=login',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_COOKIEJAR => $cookieJar,
        CURLOPT_COOKIEFILE => $cookieJar,
        CURLOPT_USERAGENT => 'Mozilla/5.0',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 302) {
        echo "❌ Login feilet\n";
        return;
    }
    
    echo "✅ Login OK\n\n";
    
    // Test flere hunder for å finne noen med badges
    $testDogs = [
        'NO36477/22',  // Fra din URL
        'NO34007/19',  // Fra valpeliste
        'NO34191/19',  // Fra valpeliste
        'NO34456/18',  // Fra valpeliste
        'NO34563/18'   // Fra valpeliste
    ];
    
    foreach ($testDogs as $dog) {
        echo "Testing: $dog\n";
        
        $url = "https://pointer.datahound.no/admin/product/getdog?id=$dog";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_COOKIEFILE => $cookieJar,
            CURLOPT_USERAGENT => 'Mozilla/5.0',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => ['Accept: application/json']
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            if ($data && isset($data['dogs'])) {
                $dog_data = $data['dogs'];
                
                echo "  Navn: " . ($dog_data['Navn'] ?? 'Ukjent') . "\n";
                echo "  Avlsh: " . ($dog_data['avlsh'] ?? 'Ingen') . "\n";
                echo "  Eliteh: " . ($dog_data['eliteh'] ?? 'Ingen') . "\n";
                echo "  Premie: " . ($dog_data['premie'] ?? 'Ingen') . "\n";
                echo "  PremieJakt: " . ($dog_data['premieJakt'] ?? 'Ingen') . "\n";
                
                // Sjekk om hunden har badges
                if (!empty($dog_data['avlsh']) || !empty($dog_data['eliteh']) || !empty($dog_data['premie'])) {
                    echo "  🏆 BADGES FUNNET!\n";
                } else {
                    echo "  ⚪ Ingen badges\n";
                }
            } else {
                echo "  ❌ Invalid response\n";
            }
        } else {
            echo "  ❌ HTTP $httpCode\n";
        }
        
        echo "\n";
        sleep(0.5); // Rate limiting
    }
    
    unlink($cookieJar);
}

testWorkingIndividualAPI();

echo "\n=== VIKTIG OPPDATERING ===\n";
echo "✅ Individuell hund API FUNGERER!\n";
echo "✅ Bruker korrekte login felter: admin_username/admin_password\n";
echo "✅ Returnerer avlsh/eliteh felter\n";
echo "⚠️ Må oppdatere NPKDataExtractor med nye login felter\n";
?>
