<?php
/**
 * Test data completeness fra NPK API
 */

require_once 'NPKDataExtractorLive.php';

echo "🔍 TESTING NPK API DATA COMPLETENESS\n\n";

$extractor = new NPKDataExtractorLive(true); // Debug mode

echo "🔐 Step 1: Authenticating...\n";
if (!$extractor->authenticate()) {
    echo "❌ Authentication failed!\n";
    exit;
}
echo "✅ Authentication successful!\n\n";

echo "📊 Step 2: Building dataset...\n";
$data = $extractor->buildCompleteDataset();

echo "📋 METADATA:\n";
print_r($data['metadata']);

echo "\n🎯 FIRST LITTER DETAILED ANALYSIS:\n";
if (!empty($data['kull'])) {
    $firstKull = $data['kull'][0];
    
    echo "📦 Main structure keys:\n";
    print_r(array_keys($firstKull));
    
    echo "\n📝 Kull Info:\n";
    print_r($firstKull['kull_info']);
    
    echo "\n👤 Oppdretter:\n";
    print_r($firstKull['oppdretter']);
    
    echo "\n🐕 Far:\n";
    print_r($firstKull['far']);
    
    echo "\n🐕 Mor:\n";
    print_r($firstKull['mor']);
    
    echo "\n📢 Annonse tekst (first 100 chars):\n";
    echo substr($firstKull['annonse_tekst'], 0, 100) . "...\n";
    
} else {
    echo "❌ No litters found!\n";
}

echo "\n🔍 COMPARING WITH OLD SYSTEM:\n";
echo "Old system had these extra fields that might be missing:\n";
echo "- Parent details (HD, jaktindeks, etc.)\n";
echo "- Ribbon/premium information\n";
echo "- Extended breeder information\n";
echo "- More detailed contact info\n";

echo "\n💡 RECOMMENDATION:\n";
echo "If data looks 'thin', we need to enhance NPKDataExtractorLive\n";
echo "to fetch more detailed information from individual dog APIs.\n";

?>
